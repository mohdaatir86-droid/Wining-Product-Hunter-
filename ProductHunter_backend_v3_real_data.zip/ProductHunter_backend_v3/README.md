# Product Hunter Backend v3

This version is designed for the real-data stage. It adds CORS, compatibility fields for the web dashboard, configurable Apify demand + supplier actors, and a dual-source endpoint that can combine marketplace demand with supplier cost.

## Render environment variables
Set these in Render → Environment:
- APIFY_API_TOKEN: your Apify token
- APIFY_DEMAND_ACTOR_ID: demand actor (example: prodiger~amazon-product-scraper)
- APIFY_DEMAND_INPUT_JSON: valid JSON input for that actor
- APIFY_SUPPLIER_ACTOR_ID: supplier actor (example: piotrv1001~aliexpress-listings-scraper)
- APIFY_SUPPLIER_INPUT_JSON: valid JSON input for that actor
- RAPIDAPI_KEY / RAPIDAPI_HOST / RAPIDAPI_URL: optional secondary provider

Do not put secrets in GitHub. Use Render environment variables.

## Endpoints
GET /health
GET /sources/status
GET /products/top?limit=50
POST /sources/apify/run
POST /sources/apify/dual-run
POST /products/ingest
