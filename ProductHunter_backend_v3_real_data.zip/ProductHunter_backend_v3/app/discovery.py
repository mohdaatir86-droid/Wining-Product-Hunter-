from .models import Product
from .engine import evaluate
from .database import upsert_product

def discover(raw_items, source):
    results=[]
    for raw in raw_items:
        try:
            # Provider normalization happens before this service.
            p=Product(**raw)
            result=evaluate(p)
            upsert_product(p,result)
            results.append(result)
        except Exception as e:
            results.append({
                "name": raw.get("name") or raw.get("title") or "Unknown",
                "source": source,
                "error": str(e),
                "verdict": "INVALID"
            })
    return sorted(results,key=lambda x:x.get("final_score",0),reverse=True)
