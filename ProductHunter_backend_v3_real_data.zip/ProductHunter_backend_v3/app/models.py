from pydantic import BaseModel, Field
from typing import Optional

class Product(BaseModel):
    name: str
    source: str = "manual"
    url: Optional[str] = None
    selling_price_usd: float
    cogs_usd: float
    shipping_usd: float = 0
    ad_cost_usd: float = 0
    rating: float = Field(0, ge=0, le=5)
    reviews: int = Field(0, ge=0)
    demand: float = Field(50, ge=0, le=100)
    competition: float = Field(50, ge=0, le=100)
    trend: float = Field(50, ge=0, le=100)
    weight_kg: float = Field(1, ge=0)

    wow_factor: float = Field(50, ge=0, le=100)
    perceived_value: float = Field(50, ge=0, le=100)
    pain_or_passion: float = Field(50, ge=0, le=100)
    frequent_use: float = Field(50, ge=0, le=100)
    golden_customer: float = Field(50, ge=0, le=100)
    quality: float = Field(50, ge=0, le=100)
    proven_sellers: float = Field(50, ge=0, le=100)
    content_potential: float = Field(50, ge=0, le=100)

    seasonal: bool = False
    fragile: bool = False
    electronic: bool = False
    ingestible: bool = False

class ScoreResult(BaseModel):
    name: str
    source: str
    selling_price_usd: float
    cogs_usd: float
    gross_margin_percent: float
    markup_multiple: float
    product_fit_score: float
    market_opportunity_score: float
    profitability_score: float
    final_score: float
    verdict: str
    hard_filter_status: str
    rejection_reasons: list[str]
    strengths: list[str]
    risks: list[str]
    recommendation: str
