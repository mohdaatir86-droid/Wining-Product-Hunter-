import os, requests

RAPIDAPI_KEY = os.getenv("RAPIDAPI_KEY")

def call_rapidapi(host: str, endpoint: str, params: dict | None = None,
                  method: str = "GET", body: dict | None = None):
    """
    Generic RapidAPI consumer adapter.
    Configure the exact API host/endpoint you subscribe to.
    """
    if not RAPIDAPI_KEY:
        raise RuntimeError("RAPIDAPI_KEY is not configured")

    url = f"https://{host}/{endpoint.lstrip('/')}"
    headers = {
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": host,
    }

    if method.upper() == "POST":
        r = requests.post(url, headers=headers, params=params, json=body, timeout=60)
    else:
        r = requests.get(url, headers=headers, params=params, timeout=60)

    r.raise_for_status()
    return r.json()
