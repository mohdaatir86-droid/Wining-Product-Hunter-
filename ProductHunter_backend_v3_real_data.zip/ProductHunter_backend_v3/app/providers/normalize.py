def normalize_product(raw: dict, source: str):
    def pick(*keys, default=None):
        for k in keys:
            v=raw.get(k)
            if v is not None and v != "":
                return v
        return default
    def num(*keys, default=0):
        v=pick(*keys, default=default)
        try: return float(v)
        except (TypeError,ValueError): return default
    def boolean(*keys):
        return bool(pick(*keys, default=False))

    return {
        "name": pick("name","title","productName","product_title",default="Unknown"),
        "source": source,
        "url": pick("url","productUrl","product_url","link"),
        "selling_price_usd": num("price","sellingPrice","salePrice","sale_price"),
        "cogs_usd": num("cogs","cost","supplierPrice","supplier_price"),
        "shipping_usd": num("shipping","shippingCost","shipping_cost"),
        "ad_cost_usd": num("adCost","estimatedAdCost","ad_cost"),
        "rating": num("rating","stars","averageRating"),
        "reviews": int(num("reviews","reviewCount","review_count")),
        "demand": num("demand","demandScore","demand_score",default=50),
        "competition": num("competition","competitionScore","competition_score",default=50),
        "trend": num("trend","trendScore","trend_score",default=50),
        "weight_kg": num("weightKg","weight_kg","weight",default=1),
        "wow_factor": num("wowFactor","wow_factor",default=50),
        "perceived_value": num("perceivedValue","perceived_value",default=50),
        "pain_or_passion": num("painOrPassion","pain_or_passion",default=50),
        "frequent_use": num("frequentUse","frequent_use",default=50),
        "golden_customer": num("goldenCustomer","golden_customer",default=50),
        "quality": num("quality",default=50),
        "proven_sellers": num("provenSellers","proven_sellers",default=50),
        "content_potential": num("contentPotential","content_potential",default=50),
        "seasonal": boolean("seasonal"),
        "fragile": boolean("fragile"),
        "electronic": boolean("electronic"),
        "ingestible": boolean("ingestible"),
    }
