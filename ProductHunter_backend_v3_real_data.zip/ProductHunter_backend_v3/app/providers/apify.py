import os, requests

APIFY_TOKEN = os.getenv("APIFY_API_TOKEN")

def run_actor(actor_id: str, actor_input: dict, wait_seconds: int = 120):
    """
    Runs an Apify Actor and returns dataset items.
    Use only Actors/data sources you are authorized to use.
    """
    if not APIFY_TOKEN:
        raise RuntimeError("APIFY_API_TOKEN is not configured")

    url = f"https://api.apify.com/v2/acts/{actor_id}/runs"
    r = requests.post(
        url,
        params={"token": APIFY_TOKEN},
        json=actor_input,
        timeout=30,
    )
    r.raise_for_status()
    run = r.json()["data"]
    run_id = run["id"]
    dataset_id = run["defaultDatasetId"]

    status_url = f"https://api.apify.com/v2/actor-runs/{run_id}"
    for _ in range(max(1, wait_seconds // 5)):
        s = requests.get(status_url, params={"token": APIFY_TOKEN}, timeout=30)
        s.raise_for_status()
        status = s.json()["data"]["status"]
        if status in ("SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT"):
            break
        import time
        time.sleep(5)

    if status != "SUCCEEDED":
        raise RuntimeError(f"Apify Actor run ended with status: {status}")

    items_url = f"https://api.apify.com/v2/datasets/{dataset_id}/items"
    items = requests.get(
        items_url,
        params={"token": APIFY_TOKEN, "clean": "true"},
        timeout=60,
    )
    items.raise_for_status()
    return items.json()
