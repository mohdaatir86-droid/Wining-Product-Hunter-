import sqlite3, json
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "product_hunter.db"

def conn():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    c=conn()
    c.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fingerprint TEXT UNIQUE,
        name TEXT NOT NULL,
        source TEXT,
        url TEXT,
        raw_json TEXT,
        result_json TEXT,
        final_score REAL,
        verdict TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.commit(); c.close()

def upsert_product(product, result):
    fingerprint=(product.name.strip().lower()+"|"+str(product.selling_price_usd)+"|"+str(product.url or "")).strip()
    c=conn()
    c.execute("""INSERT INTO products
      (fingerprint,name,source,url,raw_json,result_json,final_score,verdict)
      VALUES(?,?,?,?,?,?,?,?)
      ON CONFLICT(fingerprint) DO UPDATE SET
      raw_json=excluded.raw_json,result_json=excluded.result_json,
      final_score=excluded.final_score,verdict=excluded.verdict""",
      (fingerprint,product.name,product.source,product.url,
       json.dumps(product.model_dump()),json.dumps(result),
       result["final_score"],result["verdict"]))
    c.commit(); c.close()

def top_products(limit=50):
    c=conn()
    rows=c.execute("""SELECT id,name,source,url,final_score,verdict,created_at
                      FROM products ORDER BY final_score DESC LIMIT ?""",(limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]
