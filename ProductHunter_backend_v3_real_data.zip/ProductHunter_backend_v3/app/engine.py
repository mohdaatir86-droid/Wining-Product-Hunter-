from .models import Product

def clamp(x, lo=0, hi=100):
    return max(lo, min(hi, x))

def evaluate(p: Product):
    rejection=[]
    # Hard filters based on the user's strategy
    if p.selling_price_usd < 40:
        rejection.append("Selling price below $40")
    if p.cogs_usd <= 0:
        rejection.append("Invalid COGS")
    if p.selling_price_usd / max(p.cogs_usd, .01) < 3:
        rejection.append("Less than 3x markup")
    if p.fragile:
        rejection.append("Fragile/glass risk")
    if p.electronic:
        rejection.append("Electronics risk")
    if p.ingestible:
        rejection.append("Ingestible product")
    if p.seasonal:
        rejection.append("Seasonal product")
    if p.weight_kg > 3:
        rejection.append("Too heavy")

    markup=p.selling_price_usd/max(p.cogs_usd,.01)
    gross_margin=(p.selling_price_usd-p.cogs_usd)/p.selling_price_usd*100

    price_score=100 if 50 <= p.selling_price_usd <= 80 else (80 if p.selling_price_usd >= 40 else 0)
    cogs_score=clamp((p.cogs_usd/10)*70) if p.cogs_usd < 20 else 100
    markup_score=clamp((markup/5)*100)
    weight_score=100 if p.weight_kg <= 1 else clamp(100-(p.weight_kg-1)*40)

    # 14-point Product Fit
    fit=(
        p.wow_factor*.10 +
        price_score*.08 +
        cogs_score*.05 +
        markup_score*.10 +
        p.perceived_value*.08 +
        p.pain_or_passion*.10 +
        p.frequent_use*.06 +
        p.golden_customer*.07 +
        weight_score*.06 +
        100*(not(p.electronic or p.fragile or p.ingestible))*.05 +
        100*(not p.seasonal)*.06 +
        p.quality*.07 +
        p.proven_sellers*.05 +
        p.content_potential*.07
    )

    margin_score=clamp(gross_margin*1.5)
    ad_survival=clamp(((p.selling_price_usd-p.cogs_usd-p.shipping_usd-p.ad_cost_usd)/max(p.selling_price_usd,.01))*100)
    profitability=(margin_score*.45 + markup_score*.25 + ad_survival*.30)

    market=(
        p.demand*.30 +
        (100-p.competition)*.20 +
        p.trend*.20 +
        (p.rating/5*100)*.10 +
        clamp(p.reviews/5000*100)*.10 +
        profitability*.10
    )

    final=round(fit*.50 + market*.30 + profitability*.20,1)

    if rejection:
        verdict="❌ REJECT"
    elif final>=85:
        verdict="🔥 WINNER"
    elif final>=75:
        verdict="🟢 STRONG TEST"
    elif final>=65:
        verdict="🟡 WATCH"
    else:
        verdict="❌ DROP"

    strengths=[]
    if p.wow_factor>=75: strengths.append("Strong wow/differentiation")
    if p.pain_or_passion>=75: strengths.append("Clear pain or passion")
    if p.golden_customer>=75: strengths.append("Clear target customer")
    if p.content_potential>=75: strengths.append("Strong content potential")
    if p.proven_sellers>=75: strengths.append("Existing proof of selling")
    if p.demand>=75: strengths.append("Strong demand")
    if gross_margin>=60: strengths.append("Healthy gross margin")

    risks=[]
    if p.competition>=70: risks.append("High competition")
    if p.trend<50: risks.append("Weak trend signal")
    if p.quality<60: risks.append("Quality evidence is weak")
    if p.reviews<100: risks.append("Limited review evidence")
    if ad_survival<20: risks.append("Paid-ad economics may be weak")

    if rejection:
        recommendation="Reject before testing: " + "; ".join(rejection)
    elif final>=85:
        recommendation="High-priority winner candidate. Validate supplier quality, landing page and paid-ad economics before scaling."
    elif final>=75:
        recommendation="Good test candidate. Run a controlled creative/ad test and validate conversion rate."
    elif final>=65:
        recommendation="Keep on watchlist until stronger demand, content or economics evidence appears."
    else:
        recommendation="Do not prioritize this product."

    return {
        "name":p.name,"source":p.source,
        "selling_price_usd":p.selling_price_usd,"cogs_usd":p.cogs_usd,
        "gross_margin_percent":round(gross_margin,1),
        "markup_multiple":round(markup,2),
        "product_fit_score":round(fit,1),
        "market_opportunity_score":round(market,1),
        "profitability_score":round(profitability,1),
        "final_score":final,
        "verdict":verdict,
        "hard_filter_status":"FAIL" if rejection else "PASS",
        "rejection_reasons":rejection,
        "strengths":strengths,
        "risks":risks,
        "recommendation":recommendation
    }
