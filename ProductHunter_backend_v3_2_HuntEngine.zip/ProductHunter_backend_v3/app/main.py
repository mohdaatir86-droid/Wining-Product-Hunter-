from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Any
import asyncio, json, os, re, unicodedata
from difflib import SequenceMatcher
import httpx

app = FastAPI(title='Product Hunter API', version='3.2.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=False, allow_methods=['*'], allow_headers=['*'])

PRODUCTS: list['Product'] = []

class Product(BaseModel):
    id: str
    name: str
    category: str = 'Unknown'
    source: str = 'Unknown'
    selling_price: float
    cost_of_goods: float
    rating: float = 0
    reviews: int = 0
    rank_change_24h: int = 0
    rank_change_7d: int = 0
    wow_factor: float = 5
    perceived_value: float = 5
    pain_point: float = 5
    daily_use: float = 5
    golden_customer: float = 5
    lightweight: float = 5
    safe_shipping: float = 5
    evergreen: float = 5
    quality: float = 5
    proven_seller: float = 5
    content_potential: float = 5

    @property
    def markup(self):
        return self.selling_price / self.cost_of_goods if self.cost_of_goods else 0
    def score(self):
        price = 10 if 50 <= self.selling_price <= 80 else 8 if self.selling_price >= 40 else 2
        cogs = min(10, self.cost_of_goods) if self.cost_of_goods >= 10 else self.cost_of_goods
        markup = 10 if self.markup >= 4 else 9 if self.markup >= 3 else 6 if self.markup >= 2.5 else 4 if self.markup >= 2 else 2
        vals=[(self.wow_factor,10),(price,8),(cogs,6),(markup,8),(self.perceived_value,8),(self.pain_point,8),(self.daily_use,7),(self.golden_customer,6),(self.lightweight,5),(self.safe_shipping,5),(self.evergreen,5),(self.quality,8),(self.proven_seller,8),(self.content_potential,8)]
        return round(sum(v*w/10 for v,w in vals),1)

def verdict(score):
    return 'WINNER' if score >= 85 else 'STRONG TEST' if score >= 75 else 'WATCH' if score >= 65 else 'DROP'

def public_product(p: Product):
    score=p.score(); vc=verdict(score)
    return {
        'id':p.id,'name':p.name,'category':p.category,'source':p.source,
        'sellingPrice':p.selling_price,'costOfGoods':p.cost_of_goods,'price':p.selling_price,'cogs':p.cost_of_goods,
        'rating':p.rating,'reviews':p.reviews,'rankChange24h':p.rank_change_24h,'rankChange7d':p.rank_change_7d,
        'wowFactor':p.wow_factor,'perceivedValue':p.perceived_value,'painPoint':p.pain_point,'dailyUse':p.daily_use,
        'goldenCustomer':p.golden_customer,'golden_customer':p.golden_customer,'lightweight':p.lightweight,'safeShipping':p.safe_shipping,
        'evergreen':p.evergreen,'quality':p.quality,'provenSeller':p.proven_seller,'contentPotential':p.content_potential,
        'markup':round(p.markup,2),'winnerScore':score,'score':score,'verdict':vc
    }

def first_value(item: dict, names: list[str], default=None):
    low={str(k).lower():v for k,v in item.items()}
    for n in names:
        if n.lower() in low and low[n.lower()] not in (None,''):
            return low[n.lower()]
    return default

def as_float(v, default=0.0):
    if isinstance(v,(int,float)): return float(v)
    if v is None: return default
    m=re.search(r'[-+]?\d+(?:\.\d+)?',str(v).replace(',',''))
    return float(m.group()) if m else default

def as_int(v, default=0):
    try: return int(as_float(v,default))
    except: return default

def env_json(name, default):
    raw=os.getenv(name,'').strip()
    if not raw: return default
    try: return json.loads(raw)
    except: return default

def norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+',' ',s).strip()

def map_item(item:dict,index:int,source:str, cogs_override:float|None=None):
    name=first_value(item,['name','title','productName','product_name','productTitle','product_title'])
    price=first_value(item,['price','sellingPrice','selling_price','currentPrice','current_price','salePrice','sale_price','sale_price_value'])
    if not name or price is None: return None
    selling=as_float(price)
    cogs=as_float(first_value(item,['costOfGoods','cost_of_goods','cogs','supplierPrice','supplier_price','cost','purchasePrice','purchase_price']),0)
    if cogs_override and cogs_override>0: cogs=cogs_override
    # Supplier feeds may return price ranges; use the lowest numeric price available when no explicit COGS field exists.
    if cogs<=0:
        cogs=as_float(first_value(item,['minPrice','min_price','lowestPrice','lowest_price']),0)
    if selling<=0 or cogs<=0: return None
    return Product(
      id=str(first_value(item,['id','asin','sku','productId','product_id'],f'{source.lower()}-{index}')),
      name=str(name), category=str(first_value(item,['category','productCategory','product_category'], 'Unknown')),
      source=source, selling_price=selling, cost_of_goods=cogs,
      rating=as_float(first_value(item,['rating','stars'])), reviews=as_int(first_value(item,['reviews','reviewCount','review_count','orders','ordersSold','orders_sold'])),
      rank_change_24h=as_int(first_value(item,['rankChange24h','rank_change_24h'])), rank_change_7d=as_int(first_value(item,['rankChange7d','rank_change_7d'])),
      wow_factor=as_float(first_value(item,['wowFactor','wow_factor'],5),5), perceived_value=as_float(first_value(item,['perceivedValue','perceived_value'],5),5),
      pain_point=as_float(first_value(item,['painPoint','pain_point'],5),5), daily_use=as_float(first_value(item,['dailyUse','daily_use'],5),5),
      golden_customer=as_float(first_value(item,['goldenCustomer','golden_customer'],5),5), lightweight=as_float(first_value(item,['lightweight'],5),5),
      safe_shipping=as_float(first_value(item,['safeShipping','safe_shipping'],5),5), evergreen=as_float(first_value(item,['evergreen'],5),5),
      quality=as_float(first_value(item,['quality'],5),5), proven_seller=as_float(first_value(item,['provenSeller','proven_seller'],5),5),
      content_potential=as_float(first_value(item,['contentPotential','content_potential'],5),5)
    )

async def apify_run(actor, token, actor_input, max_wait=300):
    url=f'https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items'
    params={'token':token,'format':'json','clean':'true'}
    async with httpx.AsyncClient(timeout=max_wait+30) as client:
        r=await client.post(url,params=params,json=actor_input)
        r.raise_for_status()
        data=r.json()
        return data if isinstance(data,list) else []

@app.get('/health')
def health():
    return {'status':'ok','version':'3.2.0','products':len(PRODUCTS),'apify_configured':bool(os.getenv('APIFY_API_TOKEN')),'rapidapi_configured':bool(os.getenv('RAPIDAPI_KEY'))}

@app.get('/products/top')
def top_products(limit:int=50):
    ranked=sorted(PRODUCTS,key=lambda p:p.score(),reverse=True)[:max(1,min(limit,100))]
    return {'products':[public_product(p) for p in ranked]}

@app.post('/products/ingest')
def ingest(products:List[Product]):
    global PRODUCTS; PRODUCTS=products
    return {'accepted':len(products),'winners':sum(p.score()>=85 for p in products)}

@app.post('/sources/apify/run')
async def run_apify():
    token=os.getenv('APIFY_API_TOKEN'); actor=os.getenv('APIFY_ACTOR_ID')
    if not token or not actor: return {'status':'not_configured','message':'Set APIFY_API_TOKEN and APIFY_ACTOR_ID in Render environment variables.'}
    raw=await apify_run(actor,token,env_json('APIFY_ACTOR_INPUT_JSON',{}))
    mapped=[p for i,x in enumerate(raw) if isinstance(x,dict) and (p:=map_item(x,i,'Apify'))]
    if mapped:
        global PRODUCTS; PRODUCTS=mapped
    return {'status':'success','actor':actor,'rawItems':len(raw),'accepted':len(mapped),'winners':sum(p.score()>=85 for p in mapped)}

@app.post('/sources/apify/dual-run')
async def dual_run():
    token=os.getenv('APIFY_API_TOKEN'); demand_actor=os.getenv('APIFY_DEMAND_ACTOR_ID'); supplier_actor=os.getenv('APIFY_SUPPLIER_ACTOR_ID')
    if not token or not demand_actor or not supplier_actor:
        return {'status':'not_configured','message':'Set APIFY_API_TOKEN, APIFY_DEMAND_ACTOR_ID and APIFY_SUPPLIER_ACTOR_ID.'}
    demand=await apify_run(demand_actor,token,env_json('APIFY_DEMAND_INPUT_JSON',{'searchQueries':['best sellers home gadgets']}))
    supplier=await apify_run(supplier_actor,token,env_json('APIFY_SUPPLIER_INPUT_JSON',{'searchQueries':['home gadgets']}))
    supplier_rows=[]
    for x in supplier:
        if not isinstance(x,dict): continue
        n=norm(first_value(x,['name','title','productName','product_name','productTitle','product_title'],''))
        c=as_float(first_value(x,['price','salePrice','sale_price','minPrice','min_price','lowestPrice','lowest_price','cost','supplierPrice'],0))
        if n and c>0: supplier_rows.append((n,c))
    mapped=[]
    for i,x in enumerate(demand):
        if not isinstance(x,dict): continue
        key=norm(first_value(x,['name','title','productName','product_name','productTitle','product_title'],''))
        cogs=0
        best=0
        for sk,sc in supplier_rows:
            ratio=SequenceMatcher(None,key,sk).ratio()
            a=set(key.split()); b=set(sk.split()); overlap=len(a&b)/max(1,len(a|b))
            score=max(ratio,overlap)
            if score>best: best=score; cogs=sc
        # Only accept a supplier match when similarity is reasonably strong.
        if best < 0.42: cogs=0
        p=map_item(x,i,'Apify+Supplier',cogs)
        if p: mapped.append(p)
    if mapped:
        global PRODUCTS; PRODUCTS=mapped
    return {'status':'success','demandItems':len(demand),'supplierItems':len(supplier),'accepted':len(mapped),'winners':sum(p.score()>=85 for p in mapped)}

class HuntRequest(BaseModel):
    keyword: str = "home organization"
    marketplace: str = "IN"
    supplier_region: str = "com"
    supplier_ship_to: str = "US"
    max_products: int = 20
    amazon_pages: int = 2
    supplier_pages: int = 2
    min_price: float = 40
    max_price: float = 150
    max_cogs: float = 35
    min_markup: float = 3.0
    min_rating: float = 4.0
    min_reviews: int = 50
    min_score: float = 65

def item_text(item: dict, names: list[str], default=''):
    v=first_value(item,names,default)
    return str(v) if v is not None else default

def build_hunt_inputs(req: HuntRequest):
    q=req.keyword.strip()
    demand={
        "searchQueries":[q],
        "marketplace":req.marketplace,
        "maxProductsPerSearch":max(1,min(req.max_products,100)),
        "maxSearchPages":max(1,min(req.amazon_pages,7)),
        "proxyConfiguration":{"useApifyProxy":True,"apifyProxyGroups":["RESIDENTIAL"]}
    }
    supplier={
        "mode":"search",
        "searchQuery":q,
        "region":req.supplier_region,
        "currency":"USD",
        "language":"en_US",
        "sortBy":"orders_desc",
        "priceMin":0,
        "priceMax":max(1, int(req.max_cogs)),
        "ratingMin":req.min_rating,
        "shipTo":req.supplier_ship_to,
        "maxItems":max(1,min(req.max_products*3,1000)),
        "maxPages":max(1,min(req.supplier_pages,60)),
        "enrichReviews":False,
        "useProxy":False,
        "autoEscalateOnBlock":True
    }
    return demand, supplier

@app.post('/hunt')
async def hunt(req: HuntRequest):
    token=os.getenv('APIFY_API_TOKEN')
    demand_actor=os.getenv('APIFY_DEMAND_ACTOR_ID')
    supplier_actor=os.getenv('APIFY_SUPPLIER_ACTOR_ID')
    if not token or not demand_actor or not supplier_actor:
        return {'status':'not_configured','message':'Configure APIFY_API_TOKEN, APIFY_DEMAND_ACTOR_ID and APIFY_SUPPLIER_ACTOR_ID in Render.'}
    demand_input, supplier_input = build_hunt_inputs(req)
    demand=await apify_run(demand_actor, token, demand_input)
    supplier=await apify_run(supplier_actor, token, supplier_input)

    supplier_rows=[]
    for x in supplier:
        if not isinstance(x,dict): continue
        name=item_text(x,['name','title','productName','product_name','productTitle','product_title'])
        c=as_float(first_value(x,['salePrice','sale_price','price','minPrice','min_price','lowestPrice','lowest_price'],0))
        if name and c>0: supplier_rows.append((norm(name),c))

    mapped=[]
    for i,x in enumerate(demand):
        if not isinstance(x,dict): continue
        name=item_text(x,['name','title','productName','product_name','productTitle','product_title'])
        price=as_float(first_value(x,['price','sellingPrice','selling_price','currentPrice','current_price','salePrice','sale_price'],0))
        rating=as_float(first_value(x,['rating','stars'],0))
        reviews=as_int(first_value(x,['reviews','reviewCount','review_count'],0))
        if not name or price<=0: continue
        if price < req.min_price or price > req.max_price or rating < req.min_rating or reviews < req.min_reviews:
            continue
        key=norm(name); best=0; cogs=0
        for sk,sc in supplier_rows:
            ratio=SequenceMatcher(None,key,sk).ratio()
            a=set(key.split()); b=set(sk.split())
            overlap=len(a&b)/max(1,len(a|b))
            sim=max(ratio,overlap)
            if sim>best: best=sim; cogs=sc
        if best < 0.42 or cogs<=0 or cogs>req.max_cogs:
            continue
        p=map_item(x,i,'Amazon+AliExpress',cogs)
        if p and p.markup >= req.min_markup and p.score() >= req.min_score:
            mapped.append(p)

    mapped.sort(key=lambda p:p.score(), reverse=True)
    global PRODUCTS
    PRODUCTS=mapped
    return {
        'status':'success','keyword':req.keyword,
        'demandItems':len(demand),'supplierItems':len(supplier),
        'accepted':len(mapped),'winners':sum(p.score()>=85 for p in mapped),
        'products':[public_product(p) for p in mapped[:50]]
    }

@app.get('/sources/status')
def source_status():
    return {'apify':bool(os.getenv('APIFY_API_TOKEN')),'apify_single_actor':bool(os.getenv('APIFY_ACTOR_ID')),'apify_demand_actor':bool(os.getenv('APIFY_DEMAND_ACTOR_ID')),'apify_supplier_actor':bool(os.getenv('APIFY_SUPPLIER_ACTOR_ID')),'rapidapi':bool(os.getenv('RAPIDAPI_KEY')),'rapidapi_host':bool(os.getenv('RAPIDAPI_HOST')),'rapidapi_url':bool(os.getenv('RAPIDAPI_URL'))}
