# Product Hunter Backend v3.2
Adds POST /hunt for a user-controlled product hunt.

Example body:
{"keyword":"home organization","marketplace":"IN","max_products":20,"min_price":40,"max_price":150,"max_cogs":35,"min_markup":3,"min_rating":4,"min_reviews":50,"min_score":65}

The endpoint runs the configured Amazon and AliExpress Apify Actors, matches supplier listings, applies filters and the 14-point score, then returns ranked products.
