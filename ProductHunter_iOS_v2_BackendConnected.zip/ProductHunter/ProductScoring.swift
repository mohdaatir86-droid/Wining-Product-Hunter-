import Foundation

enum FilterStatus {
    case pass, caution, fail

    var label: String {
        switch self {
        case .pass: return "PASS"
        case .caution: return "CHECK"
        case .fail: return "FAIL"
        }
    }
}

struct FilterResult: Identifiable {
    let id = UUID()
    let number: Int
    let title: String
    let score: Double
    let status: FilterStatus
}

enum ProductScoring {
    static func filters(for p: Product) -> [FilterResult] {
        [
            FilterResult(number: 1, title: "Wow factor", score: p.wowFactor, status: status(p.wowFactor)),
            FilterResult(number: 2, title: "Selling price $40+", score: p.priceScore, status: status(p.priceScore)),
            FilterResult(number: 3, title: "COGS ~$10+", score: p.cogsScore, status: status(p.cogsScore)),
            FilterResult(number: 4, title: "3–5x markup", score: p.markupScore, status: status(p.markupScore)),
            FilterResult(number: 5, title: "High perceived value", score: p.perceivedValue, status: status(p.perceivedValue)),
            FilterResult(number: 6, title: "Pain / passion point", score: p.painPoint, status: status(p.painPoint)),
            FilterResult(number: 7, title: "Frequent use", score: p.dailyUse, status: status(p.dailyUse)),
            FilterResult(number: 8, title: "Golden customer", score: p.goldenCustomer, status: status(p.goldenCustomer)),
            FilterResult(number: 9, title: "Small & lightweight", score: p.lightweight, status: status(p.lightweight)),
            FilterResult(number: 10, title: "Safe to ship", score: p.safeShipping, status: status(p.safeShipping)),
            FilterResult(number: 11, title: "Evergreen", score: p.evergreen, status: status(p.evergreen)),
            FilterResult(number: 12, title: "Quality / actually works", score: p.quality, status: status(p.quality)),
            FilterResult(number: 13, title: "Existing seller proof", score: p.provenSeller, status: status(p.provenSeller)),
            FilterResult(number: 14, title: "Content potential", score: p.contentPotential, status: status(p.contentPotential))
        ]
    }

    private static func status(_ score: Double) -> FilterStatus {
        if score >= 8 { return .pass }
        if score >= 6 { return .caution }
        return .fail
    }
}
