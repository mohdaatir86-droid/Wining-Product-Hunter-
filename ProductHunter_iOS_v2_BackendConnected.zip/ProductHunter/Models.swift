import Foundation

struct Product: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let category: String
    let source: String
    let imageURL: String?
    let sellingPrice: Double
    let costOfGoods: Double
    let rating: Double
    let reviews: Int
    let rankChange24h: Int
    let rankChange7d: Int
    let wowFactor: Double
    let perceivedValue: Double
    let painPoint: Double
    let dailyUse: Double
    let goldenCustomer: Double
    let lightweight: Double
    let safeShipping: Double
    let evergreen: Double
    let quality: Double
    let provenSeller: Double
    let contentPotential: Double

    var markup: Double {
        guard costOfGoods > 0 else { return 0 }
        return sellingPrice / costOfGoods
    }

    var priceScore: Double {
        if sellingPrice >= 50 && sellingPrice <= 80 { return 10 }
        if sellingPrice >= 40 { return 8 }
        if sellingPrice >= 30 { return 5 }
        return 2
    }

    var cogsScore: Double {
        costOfGoods >= 10 ? 10 : max(0, costOfGoods)
    }

    var markupScore: Double {
        if markup >= 4 { return 10 }
        if markup >= 3 { return 9 }
        if markup >= 2.5 { return 6 }
        if markup >= 2 { return 4 }
        return 2
    }

    var winnerScore: Double {
        let values: [(Double, Double)] = [
            (wowFactor, 10),
            (priceScore, 8),
            (cogsScore, 6),
            (markupScore, 8),
            (perceivedValue, 8),
            (painPoint, 8),
            (dailyUse, 7),
            (goldenCustomer, 6),
            (lightweight, 5),
            (safeShipping, 5),
            (evergreen, 5),
            (quality, 8),
            (provenSeller, 8),
            (contentPotential, 8)
        ]
        return values.reduce(0) { $0 + ($1.0 * $1.1 / 10.0) }
    }

    var verdict: String {
        switch winnerScore {
        case 85...: return "WINNER"
        case 75..<85: return "STRONG TEST"
        case 65..<75: return "WATCH"
        default: return "DROP"
        }
    }

    var verdictEmoji: String {
        switch verdict {
        case "WINNER": return "🏆"
        case "STRONG TEST": return "🔥"
        case "WATCH": return "👀"
        default: return "❌"
        }
    }

    var reasons: [String] {
        var result: [String] = []
        if priceScore >= 8 { result.append("Sweet-spot selling price") }
        if markupScore >= 9 { result.append("Healthy 3x+ markup potential") }
        if wowFactor >= 8 { result.append("Strong wow factor") }
        if painPoint >= 8 { result.append("Clear pain-point solution") }
        if dailyUse >= 8 { result.append("Frequent-use potential") }
        if provenSeller >= 8 { result.append("Existing market proof") }
        if contentPotential >= 8 { result.append("Easy to demonstrate in content") }
        return result
    }
}

extension Product {
    static let demoProducts: [Product] = [
        Product(
            id: "demo-001",
            name: "Posture Relief Travel Support",
            category: "Health & Comfort",
            source: "Demo Best Sellers",
            imageURL: nil,
            sellingPrice: 59,
            costOfGoods: 14,
            rating: 4.7,
            reviews: 2840,
            rankChange24h: -18,
            rankChange7d: -41,
            wowFactor: 9,
            perceivedValue: 9,
            painPoint: 10,
            dailyUse: 9,
            goldenCustomer: 9,
            lightweight: 9,
            safeShipping: 9,
            evergreen: 9,
            quality: 9,
            provenSeller: 9,
            contentPotential: 10
        ),
        Product(
            id: "demo-002",
            name: "Modular Everyday Travel Organizer",
            category: "Travel",
            source: "Demo Best Sellers",
            imageURL: nil,
            sellingPrice: 54,
            costOfGoods: 12,
            rating: 4.6,
            reviews: 1730,
            rankChange24h: -11,
            rankChange7d: -26,
            wowFactor: 8,
            perceivedValue: 9,
            painPoint: 8,
            dailyUse: 8,
            goldenCustomer: 9,
            lightweight: 10,
            safeShipping: 10,
            evergreen: 9,
            quality: 8,
            provenSeller: 9,
            contentPotential: 9
        ),
        Product(
            id: "demo-003",
            name: "Pet Hair Removal Grooming Tool",
            category: "Pet",
            source: "Demo Best Sellers",
            imageURL: nil,
            sellingPrice: 49,
            costOfGoods: 11,
            rating: 4.5,
            reviews: 4120,
            rankChange24h: -7,
            rankChange7d: -19,
            wowFactor: 8,
            perceivedValue: 9,
            painPoint: 10,
            dailyUse: 8,
            goldenCustomer: 10,
            lightweight: 10,
            safeShipping: 10,
            evergreen: 10,
            quality: 9,
            provenSeller: 10,
            contentPotential: 10
        ),
        Product(
            id: "demo-004",
            name: "Smart Kitchen Storage System",
            category: "Home",
            source: "Demo Best Sellers",
            imageURL: nil,
            sellingPrice: 69,
            costOfGoods: 18,
            rating: 4.4,
            reviews: 1180,
            rankChange24h: -4,
            rankChange7d: -12,
            wowFactor: 8,
            perceivedValue: 9,
            painPoint: 8,
            dailyUse: 8,
            goldenCustomer: 8,
            lightweight: 7,
            safeShipping: 8,
            evergreen: 9,
            quality: 8,
            provenSeller: 8,
            contentPotential: 9
        ),
        Product(
            id: "demo-005",
            name: "Portable Outdoor Comfort Kit",
            category: "Lifestyle",
            source: "Demo Best Sellers",
            imageURL: nil,
            sellingPrice: 44,
            costOfGoods: 13,
            rating: 4.3,
            reviews: 860,
            rankChange24h: 3,
            rankChange7d: -4,
            wowFactor: 7,
            perceivedValue: 8,
            painPoint: 7,
            dailyUse: 6,
            goldenCustomer: 8,
            lightweight: 9,
            safeShipping: 9,
            evergreen: 7,
            quality: 8,
            provenSeller: 8,
            contentPotential: 9
        )
    ]
}
