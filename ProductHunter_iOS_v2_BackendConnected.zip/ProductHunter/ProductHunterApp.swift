import SwiftUI

@main
struct ProductHunterApp: App {
    @StateObject private var store = ProductStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
        }
    }
}
