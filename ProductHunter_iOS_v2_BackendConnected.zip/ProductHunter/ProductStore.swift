import Foundation
import SwiftUI

@MainActor
final class ProductStore: ObservableObject {
    @Published var products: [Product] = Product.demoProducts
    @Published var isLoading = false
    @Published var lastUpdated = Date()
    @Published var searchText = ""
    @Published var selectedCategory = "All"
    @Published var watchlist = Set<String>()

    private let watchlistKey = "productHunter.watchlist"

    init() {
        if let saved = UserDefaults.standard.array(forKey: watchlistKey) as? [String] {
            watchlist = Set(saved)
        }
    }

    var categories: [String] {
        ["All"] + Array(Set(products.map(\.category))).sorted()
    }

    var filteredProducts: [Product] {
        products
            .filter { selectedCategory == "All" || $0.category == selectedCategory }
            .filter {
                searchText.isEmpty ||
                $0.name.localizedCaseInsensitiveContains(searchText) ||
                $0.category.localizedCaseInsensitiveContains(searchText)
            }
            .sorted { $0.winnerScore > $1.winnerScore }
    }

    var winners: [Product] {
        filteredProducts.filter { $0.winnerScore >= 85 }
    }

    func refresh() async {
        isLoading = true
        defer {
            isLoading = false
            lastUpdated = Date()
        }

        if let remote = await APIClient.shared.fetchProducts() {
            products = remote
        }
    }

    func toggleWatchlist(_ product: Product) {
        if watchlist.contains(product.id) {
            watchlist.remove(product.id)
        } else {
            watchlist.insert(product.id)
        }
        UserDefaults.standard.set(Array(watchlist), forKey: watchlistKey)
    }

    func isSaved(_ product: Product) -> Bool {
        watchlist.contains(product.id)
    }
}
