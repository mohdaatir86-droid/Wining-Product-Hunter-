import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: ProductStore

    var body: some View {
        TabView {
            DashboardView()
                .tabItem { Label("Winners", systemImage: "trophy.fill") }

            DiscoverView()
                .tabItem { Label("Discover", systemImage: "magnifyingglass") }

            WatchlistView()
                .tabItem { Label("Watchlist", systemImage: "bookmark.fill") }

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape.fill") }
        }
        .tint(.orange)
    }
}

struct DashboardView: View {
    @EnvironmentObject private var store: ProductStore

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("PRODUCT HUNTER")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.orange)
                        Text("Find products worth testing.")
                            .font(.largeTitle.bold())
                        Text("14-point filter • winner score • market proof")
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 8)
                }

                Section("Top Winners") {
                    if store.winners.isEmpty {
                        Text("No 85+ winners yet. Check Discover.")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(store.winners.prefix(10)) { product in
                            NavigationLink(value: product) {
                                ProductRow(product: product)
                            }
                        }
                    }
                }

                Section("Market Snapshot") {
                    MetricRow(title: "Products analysed", value: "\(store.products.count)")
                    MetricRow(title: "85+ winners", value: "\(store.winners.count)")
                    MetricRow(title: "Avg. winner score", value: String(format: "%.1f", store.winners.map(\.winnerScore).average))
                    MetricRow(title: "Last refresh", value: store.lastUpdated.formatted(date: .omitted, time: .shortened))
                }
            }
            .navigationTitle("Hunter Dashboard")
            .navigationDestination(for: Product.self) { ProductDetailView(product: $0) }
            .refreshable { await store.refresh() }
        }
    }
}

struct DiscoverView: View {
    @EnvironmentObject private var store: ProductStore

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Category", selection: $store.selectedCategory) {
                        ForEach(store.categories, id: \.self) { Text($0).tag($0) }
                    }
                    .pickerStyle(.menu)
                }

                Section {
                    ForEach(store.filteredProducts) { product in
                        NavigationLink(value: product) {
                            ProductRow(product: product)
                        }
                    }
                }
            }
            .searchable(text: $store.searchText, prompt: "Search products")
            .navigationTitle("Discover")
            .navigationDestination(for: Product.self) { ProductDetailView(product: $0) }
        }
    }
}

struct WatchlistView: View {
    @EnvironmentObject private var store: ProductStore

    var saved: [Product] {
        store.products.filter { store.watchlist.contains($0.id) }.sorted { $0.winnerScore > $1.winnerScore }
    }

    var body: some View {
        NavigationStack {
            List {
                if saved.isEmpty {
                    ContentUnavailableView("No saved products", systemImage: "bookmark", description: Text("Save products from Discover to compare them later."))
                } else {
                    ForEach(saved) { product in
                        NavigationLink(value: product) {
                            ProductRow(product: product)
                        }
                    }
                    .onDelete { offsets in
                        for index in offsets {
                            store.toggleWatchlist(saved[index])
                        }
                    }
                }
            }
            .navigationTitle("Watchlist")
            .navigationDestination(for: Product.self) { ProductDetailView(product: $0) }
        }
    }
}

struct ProductDetailView: View {
    @EnvironmentObject private var store: ProductStore
    let product: Product

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Text(product.verdictEmoji)
                        .font(.system(size: 42))
                    Text(product.name)
                        .font(.title.bold())
                    Text(product.category)
                        .foregroundStyle(.secondary)

                    HStack {
                        ScoreBadge(score: product.winnerScore)
                        Text(product.verdict)
                            .font(.headline)
                            .foregroundStyle(.orange)
                    }

                    HStack {
                        Text("$\(product.sellingPrice, specifier: "%.0f") sell")
                        Text("•")
                        Text("$\(product.costOfGoods, specifier: "%.0f") COGS")
                        Text("•")
                        Text("\(product.markup, specifier: "%.1f")x")
                    }
                    .font(.subheadline.weight(.semibold))
                }
                .padding(.vertical, 6)
            }

            Section("Why it can win") {
                if product.reasons.isEmpty {
                    Text("Needs more evidence.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(product.reasons, id: \.self) { reason in
                        Label(reason, systemImage: "checkmark.circle.fill")
                    }
                }
            }

            Section("14-Point Filter") {
                ForEach(ProductScoring.filters(for: product)) { filter in
                    FilterRow(filter: filter)
                }
            }

            Section("Market Signals") {
                MetricRow(title: "Rating", value: String(format: "%.1f ★", product.rating))
                MetricRow(title: "Reviews", value: product.reviews.formatted())
                MetricRow(title: "24h rank", value: product.rankChange24h >= 0 ? "+\(product.rankChange24h)" : "\(product.rankChange24h)")
                MetricRow(title: "7d rank", value: product.rankChange7d >= 0 ? "+\(product.rankChange7d)" : "\(product.rankChange7d)")
                MetricRow(title: "Source", value: product.source)
            }
        }
        .navigationTitle("Product Analysis")
        .toolbar {
            Button {
                store.toggleWatchlist(product)
            } label: {
                Image(systemName: store.isSaved(product) ? "bookmark.fill" : "bookmark")
            }
        }
    }
}

struct ProductRow: View {
    let product: Product

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(.orange.opacity(0.12))
                Text(product.verdictEmoji)
                    .font(.title2)
            }
            .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 4) {
                Text(product.name)
                    .font(.headline)
                    .lineLimit(2)
                Text("\(product.category) • $\(product.sellingPrice, specifier: "%.0f") • \(product.markup, specifier: "%.1f")x")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text("\(product.winnerScore, specifier: "%.0f")")
                .font(.headline.bold())
                .foregroundStyle(.orange)
        }
    }
}

struct FilterRow: View {
    let filter: FilterResult

    var body: some View {
        HStack {
            Text("\(filter.number)")
                .font(.caption.bold())
                .frame(width: 24, height: 24)
                .background(.secondary.opacity(0.12), in: Circle())

            Text(filter.title)

            Spacer()

            Text("\(filter.score, specifier: "%.0f")/10")
                .font(.caption.weight(.semibold))
                .foregroundStyle(filter.status == .pass ? .green : filter.status == .caution ? .orange : .red)

            Text(filter.status.label)
                .font(.caption2.bold())
                .foregroundStyle(filter.status == .pass ? .green : filter.status == .caution ? .orange : .red)
        }
    }
}

struct ScoreBadge: View {
    let score: Double

    var body: some View {
        Text("\(score, specifier: "%.0f")/100")
            .font(.headline.bold())
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(.orange.opacity(0.15), in: Capsule())
            .foregroundStyle(.orange)
    }
}

struct MetricRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).fontWeight(.semibold)
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: ProductStore

    var body: some View {
        NavigationStack {
            Form {
                Section("Product Hunter") {
                    LabeledContent("Version", value: "iOS v1.0")
                    LabeledContent("Scoring engine", value: "14-point / 100")
                    LabeledContent("Data mode", value: "Demo + backend ready")
                }

                Section("Data Sources") {
                    Label("Apify", systemImage: "shippingbox")
                    Label("RapidAPI", systemImage: "bolt.horizontal")
                    Label("Amazon / marketplace APIs", systemImage: "cart")
                }

                Section("Refresh") {
                    Button {
                        Task { await store.refresh() }
                    } label: {
                        HStack {
                            Text("Refresh live data")
                            Spacer()
                            if store.isLoading {
                                ProgressView()
                            }
                        }
                    }
                }

                Section {
                    Text("Demo data is included so the app works before the backend is connected. Replace the API URL in APIClient.swift when the Product Hunter backend is deployed.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }
}

extension Array where Element == Double {
    var average: Double {
        guard !isEmpty else { return 0 }
        return reduce(0, +) / Double(count)
    }
}
