# Product Hunter Backend v1

FastAPI backend for the Product Hunter iOS app.

## Endpoints
- `GET /health`
- `GET /products/top?limit=50`
- `POST /products/ingest`
- `POST /sources/apify/run`
- `GET /sources/rapidapi/status`

## Run locally
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Environment
Copy `.env.example` to `.env` and add your own API credentials.

The backend deliberately keeps marketplace/provider credentials server-side; never put Apify or RapidAPI secrets into the iOS app.

## Next integration
Configure a permitted Apify actor and/or RapidAPI provider for the exact marketplace/source you want to ingest. Then map its output into the Product schema and send it to `/products/ingest`.
