from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, List
import os, httpx

app = FastAPI(title="Product Hunter API", version="1.0.0")

PRODUCTS = []

class Product(BaseModel):
    id: str
    name: str
    category: str = "Unknown"
    source: str = "Unknown"
    selling_price: float
    cost_of_goods: float
    rating: float = 0
    reviews: int = 0
    rank_change_24h: int = 0
    rank_change_7d: int = 0
    wow_factor: float = 5
    perceived_value: float = 5
    pain_point: float = 5
    daily_use: float = 5
    golden_customer: float = 5
    lightweight: float = 5
    safe_shipping: float = 5
    evergreen: float = 5
    quality: float = 5
    proven_seller: float = 5
    content_potential: float = 5

    @property
    def markup(self):
        return self.selling_price / self.cost_of_goods if self.cost_of_goods else 0

    def score(self):
        price = 10 if 50 <= self.selling_price <= 80 else 8 if self.selling_price >= 40 else 2
        cogs = min(10, self.cost_of_goods) if self.cost_of_goods >= 10 else self.cost_of_goods
        markup = 10 if self.markup >= 4 else 9 if self.markup >= 3 else 6 if self.markup >= 2.5 else 4 if self.markup >= 2 else 2
        values = [
            (self.wow_factor,10),(price,8),(cogs,6),(markup,8),
            (self.perceived_value,8),(self.pain_point,8),(self.daily_use,7),
            (self.golden_customer,6),(self.lightweight,5),(self.safe_shipping,5),
            (self.evergreen,5),(self.quality,8),(self.proven_seller,8),
            (self.content_potential,8)
        ]
        return round(sum(v*w/10 for v,w in values), 1)

def public_product(p: Product):
    score = p.score()
    verdict = "WINNER" if score >= 85 else "STRONG TEST" if score >= 75 else "WATCH" if score >= 65 else "DROP"
    return {
        "id": p.id, "name": p.name, "category": p.category, "source": p.source,
        "sellingPrice": p.selling_price, "costOfGoods": p.cost_of_goods,
        "rating": p.rating, "reviews": p.reviews,
        "rankChange24h": p.rank_change_24h, "rankChange7d": p.rank_change_7d,
        "wowFactor": p.wow_factor, "perceivedValue": p.perceived_value,
        "painPoint": p.pain_point, "dailyUse": p.daily_use,
        "goldenCustomer": p.golden_customer, "lightweight": p.lightweight,
        "safeShipping": p.safe_shipping, "evergreen": p.evergreen,
        "quality": p.quality, "provenSeller": p.proven_seller,
        "contentPotential": p.content_potential,
        "markup": round(p.markup, 2), "winnerScore": score, "verdict": verdict
    }

@app.get("/health")
def health():
    return {"status": "ok", "products": len(PRODUCTS)}

@app.get("/products/top")
def top_products(limit: int = 50):
    ranked = sorted(PRODUCTS, key=lambda p: p.score(), reverse=True)[:limit]
    return {"products": [public_product(p) for p in ranked]}

@app.post("/products/ingest")
def ingest(products: List[Product]):
    global PRODUCTS
    PRODUCTS = products
    return {"accepted": len(products), "winners": sum(p.score() >= 85 for p in products)}

@app.post("/sources/apify/run")
async def run_apify():
    token = os.getenv("APIFY_API_TOKEN")
    actor = os.getenv("APIFY_ACTOR_ID")
    if not token or not actor:
        return {"status": "not_configured", "message": "Set APIFY_API_TOKEN and APIFY_ACTOR_ID."}
    url = f"https://api.apify.com/v2/acts/{actor}/runs?token={token}"
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, json={"input": {}})
        return {"status_code": r.status_code, "data": r.json()}

@app.get("/sources/rapidapi/status")
def rapidapi_status():
    return {
        "configured": bool(os.getenv("RAPIDAPI_KEY")),
        "host_configured": bool(os.getenv("RAPIDAPI_HOST"))
    }
