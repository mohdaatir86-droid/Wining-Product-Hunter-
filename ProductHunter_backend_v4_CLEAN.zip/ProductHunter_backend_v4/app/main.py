
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Any
from difflib import SequenceMatcher
import os, re, json, unicodedata, httpx, asyncio

app=FastAPI(title="Product Hunter API",version="4.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["*"],allow_headers=["*"])
PRODUCTS=[]

class HuntRequest(BaseModel):
    keyword:str=Field(default="home organization",min_length=2)
    marketplace:str="US"
    supplier_ship_to:str="US"
    currency:str="USD"
    max_products:int=20
    amazon_pages:int=2
    supplier_pages:int=2
    min_price:float=40
    max_price:float=80
    max_cogs:float=20
    min_markup:float=3
    min_rating:float=4.2
    min_reviews:int=100
    min_score:float=75

def first(d,names,default=None):
    if not isinstance(d,dict): return default
    low={str(k).lower():v for k,v in d.items()}
    for n in names:
        v=low.get(n.lower())
        if v not in (None,""): return v
    return default

def num(v,default=0):
    if isinstance(v,(int,float)): return float(v)
    if v is None:return default
    m=re.search(r"-?\d+(?:\.\d+)?",str(v).replace(",",""))
    return float(m.group()) if m else default

def integer(v,default=0):
    try:return int(num(v,default))
    except:return default

def norm(s):
    s=unicodedata.normalize("NFKD",str(s)).encode("ascii","ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+"," ",s).strip()

def name_of(x):
    return str(first(x,["name","title","productName","product_name","productTitle","product_title","itemTitle"],"")).strip()

def price_of(x):
    return num(first(x,["price","currentPrice","current_price","salePrice","sale_price","sellingPrice","selling_price","priceValue","price_value"],0))

def rating_of(x): return num(first(x,["rating","stars","starRating","star_rating"],0))
def reviews_of(x): return integer(first(x,["reviews","reviewCount","review_count","ratingsTotal","ratings_total","orders","orderCount","order_count"],0))

def score_product(selling,cogs,rating,reviews,name):
    # Transparent heuristic aligned to the 14-point framework.
    markup=selling/cogs if cogs else 0
    wow=7 if len(name)>15 else 5
    price=10 if 50<=selling<=80 else 8 if selling>=40 else 3
    cogs=10 if cogs>=10 else max(1,cogs)
    mk=10 if markup>=4 else 9 if markup>=3 else 6 if markup>=2.5 else 4 if markup>=2 else 2
    perceived=8 if selling>=50 else 6
    pain=7; daily=7; golden=7; light=8; safe=8; evergreen=7; quality=min(9,5+rating)
    proven=9 if reviews>=1000 else 8 if reviews>=100 else 6
    content=8
    vals=[(wow,10),(price,8),(cogs,6),(mk,8),(perceived,8),(pain,8),(daily,7),(golden,6),(light,5),(safe,5),(evergreen,5),(quality,8),(proven,8),(content,8)]
    return round(sum(v*w/10 for v,w in vals),1)

def verdict(s): return "WINNER" if s>=85 else "STRONG TEST" if s>=75 else "WATCH" if s>=65 else "DROP"

async def run_actor(actor,token,payload):
    if not actor: raise RuntimeError("Apify actor ID is missing.")
    url=f"https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items"
    try:
        async with httpx.AsyncClient(timeout=360) as c:
            r=await c.post(url,params={"token":token,"format":"json","clean":"true"},json=payload)
            if r.status_code>=400:
                body=r.text[:1200]
                raise RuntimeError(f"Apify actor {actor} returned HTTP {r.status_code}: {body}")
            data=r.json()
            if not isinstance(data,list): raise RuntimeError(f"Apify actor {actor} returned unexpected data.")
            return data
    except httpx.TimeoutException:
        raise RuntimeError(f"Apify actor {actor} timed out after 6 minutes.")

def sim(a,b):
    aa=set(norm(a).split()); bb=set(norm(b).split())
    overlap=len(aa&bb)/max(1,len(aa|bb))
    return max(SequenceMatcher(None,norm(a),norm(b)).ratio(),overlap)

def output(p):
    return p

@app.get("/health")
def health():
    return {"status":"ok","version":"4.0.0","products":len(PRODUCTS),
            "apify_configured":bool(os.getenv("APIFY_API_TOKEN")),
            "demand_actor_configured":bool(os.getenv("APIFY_DEMAND_ACTOR_ID")),
            "supplier_actor_configured":bool(os.getenv("APIFY_SUPPLIER_ACTOR_ID"))}

@app.get("/sources/status")
def sources_status():
    return {"apify":bool(os.getenv("APIFY_API_TOKEN")),
            "demand_actor":os.getenv("APIFY_DEMAND_ACTOR_ID",""),
            "supplier_actor":os.getenv("APIFY_SUPPLIER_ACTOR_ID","")}

@app.get("/products/top")
def top(limit:int=50):
    return {"products":PRODUCTS[:max(1,min(limit,100))]}

@app.post("/hunt")
async def hunt(req:HuntRequest):
    token=os.getenv("APIFY_API_TOKEN")
    demand_actor=os.getenv("APIFY_DEMAND_ACTOR_ID")
    supplier_actor=os.getenv("APIFY_SUPPLIER_ACTOR_ID")
    if not token or not demand_actor or not supplier_actor:
        return {"status":"error","stage":"configuration",
                "message":"APIFY_API_TOKEN, APIFY_DEMAND_ACTOR_ID and APIFY_SUPPLIER_ACTOR_ID must be configured in Render."}

    demand_input={
        "searchQueries":[req.keyword.strip()],
        "marketplace":req.marketplace,
        "maxProductsPerSearch":max(5,min(req.max_products,50)),
        "maxSearchPages":max(1,min(req.amazon_pages,5)),
        "proxyConfiguration":{"useApifyProxy":True,"apifyProxyGroups":["RESIDENTIAL"]}
    }
    supplier_input={
        "mode":"search","searchQuery":req.keyword.strip(),"region":"com",
        "currency":"USD","language":"en_US","sortBy":"orders_desc",
        "priceMin":0,"priceMax":max(1,int(req.max_cogs)),
        "ratingMin":req.min_rating,"shipTo":req.supplier_ship_to,
        "maxItems":max(20,min(req.max_products*5,100)),
        "maxPages":max(1,min(req.supplier_pages,10)),
        "enrichReviews":False,"useProxy":False,"autoEscalateOnBlock":True
    }

    try:
        demand=await run_actor(demand_actor,token,demand_input)
    except Exception as e:
        return {"status":"error","stage":"amazon","message":str(e)}
    try:
        supplier=await run_actor(supplier_actor,token,supplier_input)
    except Exception as e:
        return {"status":"error","stage":"supplier","message":str(e)}

    suppliers=[]
    for x in supplier:
        n=name_of(x); c=price_of(x)
        if n and c>0: suppliers.append((n,c,x))

    candidates=[]
    filtered={"price":0,"rating":0,"reviews":0,"supplier_match":0,"cogs":0,"markup":0,"score":0}
    for i,x in enumerate(demand):
        n=name_of(x); p=price_of(x); r=rating_of(x); rev=reviews_of(x)
        if not n or p<=0: continue
        if p<req.min_price or p>req.max_price: filtered["price"]+=1; continue
        if r<req.min_rating: filtered["rating"]+=1; continue
        if rev<req.min_reviews: filtered["reviews"]+=1; continue

        bestsim=0; bestc=0; bestsupplier=None
        for sn,sc,sx in suppliers:
            z=sim(n,sn)
            if z>bestsim: bestsim=z; bestc=sc; bestsupplier=sx
        if bestsim<0.38 or bestc<=0: filtered["supplier_match"]+=1; continue
        if bestc>req.max_cogs: filtered["cogs"]+=1; continue
        markup=p/bestc
        if markup<req.min_markup: filtered["markup"]+=1; continue
        s=score_product(p,bestc,r,rev,n)
        if s<req.min_score: filtered["score"]+=1; continue
        candidates.append({
            "id":str(first(x,["asin","id","sku","productId"],f"amazon-{i}")),
            "name":n,"sellingPrice":round(p,2),"costOfGoods":round(bestc,2),
            "markup":round(markup,2),"rating":r,"reviews":rev,
            "winnerScore":s,"score":s,"verdict":verdict(s),
            "source":"Amazon + AliExpress","supplierMatchScore":round(bestsim,2),
            "category":str(first(x,["category","productCategory"],"Unknown")),
            "image":first(x,["image","imageUrl","image_url","thumbnail","thumbnailUrl"],None),
            "url":first(x,["url","productUrl","product_url","detailPageURL"],None)
        })
    candidates.sort(key=lambda x:x["score"],reverse=True)
    PRODUCTS[:]=candidates[:50]
    return {"status":"success","keyword":req.keyword,"demandItems":len(demand),
            "supplierItems":len(supplier),"accepted":len(candidates),
            "winners":sum(x["score"]>=85 for x in candidates),
            "filters":filtered,"products":candidates[:50]}

@app.get("/")
def root(): return {"service":"Product Hunter API","version":"4.0.0","hunt":"/hunt","health":"/health"}
