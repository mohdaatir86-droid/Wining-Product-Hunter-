# Product Hunter Backend v4
Clean hunt API. Required Render environment variables:
APIFY_API_TOKEN
APIFY_DEMAND_ACTOR_ID=prodiger~amazon-product-scraper
APIFY_SUPPLIER_ACTOR_ID=crawlerbros~aliexpress-scraper

If deployed from the ZIP in a GitHub repo root, use:
Build Command:
python -m zipfile -e ProductHunter_backend_v4.zip backend && pip install -r backend/ProductHunter_backend_v4/requirements.txt
Start Command:
cd backend/ProductHunter_backend_v4 && uvicorn app.main:app --host 0.0.0.0 --port $PORT
