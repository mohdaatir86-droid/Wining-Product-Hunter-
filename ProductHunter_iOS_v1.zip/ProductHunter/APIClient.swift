import Foundation

struct ProductAPIResponse: Codable {
    let products: [Product]
}

actor APIClient {
    static let shared = APIClient()

    // Replace this with your Product Hunter backend URL when deployed.
    private let baseURL = "https://YOUR-BACKEND-URL.example.com"

    func fetchProducts() async -> [Product]? {
        guard let url = URL(string: baseURL + "/products/top?limit=50") else {
            return nil
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
                return nil
            }
            return try JSONDecoder().decode(ProductAPIResponse.self, from: data).products
        } catch {
            return nil
        }
    }
}
