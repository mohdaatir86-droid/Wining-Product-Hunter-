# Product Hunter iOS

Native SwiftUI starter for the Product Hunter app.

## Included in v1
- Winner Dashboard
- Discover/search/category filtering
- Watchlist stored locally
- 14-point winning-product filter
- Transparent 0–100 Winner Score
- Winner / Strong Test / Watch / Drop verdicts
- Price, COGS and markup analysis
- 24h and 7d rank-change fields
- Demo products so the app runs without a backend
- Backend-ready API client for `/products/top?limit=50`
- Codemagic iOS simulator build configuration

## 14-point scoring
1. Wow factor
2. Selling price $40+
3. COGS ~$10+
4. 3–5x markup
5. High perceived value
6. Pain / passion point
7. Frequent use
8. Golden customer
9. Small & lightweight
10. Safe to ship
11. Evergreen
12. Quality / actually works
13. Existing seller proof
14. Content potential

Weights total 100 points.

## Build
Open `ProductHunter.xcodeproj` in Xcode or use Codemagic.

The first Codemagic workflow builds an unsigned iOS Simulator `.app`, so Apple Developer membership is not required for that validation build.

To install on a real iPhone/TestFlight, configure Apple signing and the Apple Developer account, then add the production workflow.
