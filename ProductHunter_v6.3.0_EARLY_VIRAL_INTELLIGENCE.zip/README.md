# Product Hunter v6.3 — Early Viral Intelligence

Built directly from the uploaded Product Hunter v6.2 Demand Signals package.

## v6.3 upgrades
- Keeps the existing 14-point product framework.
- Removes selling-price hard filtering.
- Rating/review thresholds are scoring signals, not visibility gates.
- Supplier match/COGS/markup are scoring/enrichment signals; demand candidates are not hidden just because supplier data is missing.
- Adds ScrapingAnt as a third product-data provider alongside Crawlbase and Apify.
- Adds source health tracking at `/source-health`.
- Adds SerpApi Amazon Product enrichment for actual Amazon Best Sellers Rank when available.
- Keeps Google Trends + Pinterest Trends demand signals.
- Adds Early Viral Score based on acceleration/momentum rather than absolute sales alone.
- Adds Opportunity Score combining demand, acceleration, ranking, product quality, economics, competition and content potential.
- Adds viral classifications: EARLY VIRAL, RISING FAST, RISING, STABLE, INSUFFICIENT DATA.
- Preserves snapshot-based sales/rank history and never fabricates missing data.
- Fixes the v6.2 enrichment bug that referenced an undefined source record.
- Cleans the UI to practical controls: category, USA market, opportunity type, minimum AI score, sort order and result count.
- Product cards emphasize Opportunity, Early Viral, Demand, Rank movement, sales velocity and competition.

## Required Render environment variables
Existing:
- CRAWLBASE_TOKEN
- APIFY_API_TOKEN
- APIFY_DEMAND_ACTOR_ID
- APIFY_SUPPLIER_ACTOR_ID

Demand signals:
- SERPAPI_API_KEY
- PINTEREST_ACCESS_TOKEN (optional)

New:
- SCRAPINGANT_API_KEY

## Ranking accuracy rule
Amazon Best Sellers Rank is only shown when the Amazon product source exposes an actual Best Sellers Rank. Search-result position is never mislabeled as sales rank.

Sales 24h/7d are derived only from repeated cumulative snapshots where the source exposes cumulative orders/sales. First observation shows `Collecting` rather than inventing a value.

## Deploy
1. Replace Render `app/main.py` with the included `app/main.py`.
2. Ensure `SCRAPINGANT_API_KEY` and existing `SERPAPI_API_KEY` are configured in Render.
3. Replace the hosted/root `index.html` with the included `index.html`.
4. Do not delete the existing database/environment configuration.
5. After deployment test:
   - `/health`
   - `/sources/status`
   - `/source-health`
   - `/pipeline/latest`
   - `/scraper-data/latest`
   - `/products/accepted`
   - `/products/trending`
   - `/products/winners`
