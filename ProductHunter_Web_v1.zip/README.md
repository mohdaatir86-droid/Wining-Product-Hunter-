# Product Hunter Web
Static web dashboard for Product Hunter AI. It connects directly to the Render FastAPI backend:
https://wining-product-hunter.onrender.com

Deploy on Vercel, Netlify, GitHub Pages, or any static host. No server required.
