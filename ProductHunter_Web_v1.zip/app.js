const API="https://wining-product-hunter.onrender.com";
let products=[];
const $=id=>document.getElementById(id);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function render(){
 const q=$("search").value.toLowerCase(), v=$("verdict").value, s=$("sort").value;
 let a=products.filter(p=>(!q||String(p.name||"").toLowerCase().includes(q))&&(!v||v==="ALL"||p.verdict===v));
 a.sort((x,y)=>s==="score"?y.score-x.score:s==="price"?y.price-x.price:String(x.name).localeCompare(String(y.name)));
 $("count").textContent=a.length;$("winners").textContent=products.filter(p=>p.verdict==="WINNER").length;
 $("avg").textContent=products.length?(products.reduce((n,p)=>n+(p.score||0),0)/products.length).toFixed(1):"—";
 $("empty").style.display=a.length?"none":"block";
 $("grid").innerHTML=a.map(p=>`<article class="card"><div class="cardTop"><div><b>${esc(p.name)}</b><div class="meta">${esc(p.category||"Product")}</div></div><div class="score">${p.score??0}</div></div><div class="pill">${esc(p.verdict||"WATCH")}</div><div class="bar"><div class="fill" style="width:${Math.min(100,p.score||0)}%"></div></div><div class="row"><span class="muted">Price</span><b>$${Number(p.price||0).toFixed(0)}</b></div><div class="row"><span class="muted">COGS</span><span>$${Number(p.cogs||0).toFixed(0)}</span></div><div class="row"><span class="muted">Markup</span><span>${Number(p.markup||0).toFixed(1)}×</span></div><div class="row"><span class="muted">Customer</span><span>${esc(p.golden_customer||"—")}</span></div></article>`).join("");
}
async function load(){
 $("statusText").textContent="Checking backend…";
 try{
  const h=await fetch(API+"/health"); const hd=await h.json();
  $("statusText").textContent="Backend online";$("statusDot").style.background="#22c55e";$("backend").textContent="ONLINE";
  const r=await fetch(API+"/products/top?limit=50"); const d=await r.json(); products=d.products||[];
 }catch(e){$("statusText").textContent="Backend unavailable";$("statusDot").style.background="#ef4444";$("backend").textContent="OFFLINE";products=[]}
 render();
}
["search","verdict","sort"].forEach(id=>$(id).addEventListener("input",render));
$("refresh").onclick=load;$("docs").onclick=()=>location.href=API+"/docs";load();
