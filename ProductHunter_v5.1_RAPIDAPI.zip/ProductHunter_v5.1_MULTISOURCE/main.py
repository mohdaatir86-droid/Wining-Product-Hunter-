from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, Any
from difflib import SequenceMatcher
import os, re, unicodedata, httpx, sqlite3, hashlib, json, asyncio, time
from datetime import datetime, timezone

VERSION="5.1.0"
DB_PATH=os.getenv("PRODUCT_HUNTER_DB","product_hunter.db")

app=FastAPI(title="Product Hunter API", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

CATEGORIES={
 "kitchen_utility":["kitchen utility","kitchen organizer","kitchen storage","pantry organizer","drawer organizer","countertop organizer","sink organizer","kitchen cleaning","cooking tool","meal prep","spice organizer"],
 "home_decor":["home decor","home decoration","wall decor","table decor","living room decor","bedroom decor","decorative storage","aesthetic home","minimalist decor","home accessory"]
}
WEIGHTS={"wow_factor":10,"price":8,"cogs":6,"markup":8,"perceived_value":8,"pain_point":8,"daily_use":7,"golden_customer":6,"lightweight":5,"safe_shipping":5,"evergreen":5,"quality":8,"proven_seller":8,"content_potential":8}

# Multi-source discovery. Existing Amazon + AliExpress remain active.
SOURCE_ACTORS={
 "amazon":os.getenv("APIFY_DEMAND_ACTOR_ID","prodiger~amazon-product-scraper"),
 "walmart":os.getenv("APIFY_WALMART_ACTOR_ID","prodiger~walmart-scraper"),
 "etsy":os.getenv("APIFY_ETSY_ACTOR_ID","crawlerbros~etsy-scraper"),
 "temu":os.getenv("APIFY_TEMU_ACTOR_ID","apivault_labs~temu-product-scraper"),
 "home_depot":os.getenv("APIFY_HOMEDEPOT_ACTOR_ID","crawlerbros~homedepot-scraper"),
 "target":os.getenv("APIFY_TARGET_ACTOR_ID","automation-lab~target-scraper"),
 "aliexpress":os.getenv("APIFY_SUPPLIER_ACTOR_ID","crawlerbros~aliexpress-scraper"),
}
DEMAND_SOURCES=["amazon","walmart","etsy","temu","home_depot","target"]
SUPPLIER_SOURCES=["aliexpress"]

# Optional RapidAPI fallback. This is independent of Apify usage limits.
RAPIDAPI_KEY=os.getenv("RAPIDAPI_KEY")
RAPIDAPI_AMAZON_HOST=os.getenv("RAPIDAPI_AMAZON_HOST","amazon-search-api1.p.rapidapi.com")
RAPIDAPI_AMAZON_URL=os.getenv("RAPIDAPI_AMAZON_URL","https://amazon-search-api1.p.rapidapi.com/amazon-serp.php")
RAPIDAPI_ALIEXPRESS_HOST=os.getenv("RAPIDAPI_ALIEXPRESS_HOST","aliexpress-api2.p.rapidapi.com")
RAPIDAPI_ALIEXPRESS_URL=os.getenv("RAPIDAPI_ALIEXPRESS_URL","https://aliexpress-api2.p.rapidapi.com/search")

class HuntRequest(BaseModel):
    category:str="all"
    keyword:Optional[str]=None
    marketplace:str="US"
    supplier_ship_to:str="US"
    currency:str="USD"
    max_products:int=20
    amazon_pages:int=2
    supplier_pages:int=2
    min_price:float=40
    max_price:float=150
    max_cogs:float=35
    min_markup:float=3
    min_rating:float=4
    min_reviews:int=50
    min_score:float=60


def db():
    c=sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("CREATE TABLE IF NOT EXISTS products (fingerprint TEXT PRIMARY KEY, data TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS hunts (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, status TEXT, started_at TEXT, finished_at TEXT, demand_items INTEGER DEFAULT 0, supplier_items INTEGER DEFAULT 0, accepted INTEGER DEFAULT 0, error TEXT)")
    c.commit(); return c

def now(): return datetime.now(timezone.utc).isoformat()

def fp(name,url=None): return hashlib.sha256((norm(name)+"|"+norm(url or "")).encode()).hexdigest()

def save_product(p):
    c=db(); t=now(); f=fp(p.get("name",""),p.get("url"))
    c.execute("INSERT INTO products(fingerprint,data,created_at,updated_at) VALUES(?,?,?,?) ON CONFLICT(fingerprint) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at",(f,json.dumps(p,ensure_ascii=False),t,t)); c.commit(); c.close()

def products(limit=50,category=None):
    c=db(); rows=c.execute("SELECT data FROM products ORDER BY json_extract(data,'$.score') DESC, updated_at DESC LIMIT ?",(max(1,min(limit,200)),)).fetchall(); c.close()
    out=[json.loads(r[0]) for r in rows]
    return [p for p in out if not category or p.get("category_key")==category]

def first(d,names,default=None):
    if not isinstance(d,dict): return default
    low={str(k).lower():v for k,v in d.items()}
    for n in names:
        v=low.get(n.lower())
        if v not in (None,""): return v
    return default

def num(v,default=0):
    if isinstance(v,(int,float)): return float(v)
    if v is None:return default
    m=re.search(r"-?\d+(?:\.\d+)?",str(v).replace(",",""))
    return float(m.group()) if m else default

def integer(v,default=0):
    try:return int(num(v,default))
    except:return default

def norm(s):
    s=unicodedata.normalize("NFKD",str(s)).encode("ascii","ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+"," ",s).strip()

def name_of(x): return str(first(x,["name","title","productName","product_name","productTitle","product_title","itemTitle"],"")).strip()
def price_of(x): return num(first(x,["price","currentPrice","current_price","salePrice","sale_price","sellingPrice","selling_price","priceValue","price_value"],0))
def rating_of(x): return num(first(x,["rating","stars","starRating","star_rating"],0))
def reviews_of(x): return integer(first(x,["reviews","reviewCount","review_count","ratingsTotal","ratings_total","orders","orderCount","order_count"],0))
def desc_of(x): return str(first(x,["description","productDescription","product_description","features","bullets","category"],""))

def classify(text):
    t=norm(text)
    scores={k:sum(1 for kw in kws if norm(kw) in t) for k,kws in CATEGORIES.items()}
    best=max(scores,key=scores.get)
    return best if scores[best]>0 else None

def hard_reject(name,desc):
    t=norm(name+" "+desc)
    bad=["electronic","battery","bluetooth","usb","smart device","glass vase","glassware","fragile","edible","food supplement","drink","beverage","seasonal","christmas","halloween","valentine","easter"]
    return any(x in t for x in bad)

def sim(a,b):
    aa=set(norm(a).split()); bb=set(norm(b).split())
    overlap=len(aa&bb)/max(1,len(aa|bb))
    return max(SequenceMatcher(None,norm(a),norm(b)).ratio(),overlap)

def score_product(selling,cogs,rating,reviews,name,desc,category):
    markup=selling/cogs if cogs else 0
    t=norm(name+" "+desc)
    def s(cond,yes=10,no=4): return yes if cond else no
    parts={
      "wow_factor": s(len(name)>=18 and len(set(norm(name).split()))>=4,9,5),
      "price": 10 if 50<=selling<=80 else 8 if selling>=40 else 0,
      "cogs": 10 if 10<=cogs<=35 else 7 if cogs>0 else 0,
      "markup": 10 if markup>=4 else 9 if markup>=3 else 0,
      "perceived_value": 9 if selling>=50 else 7,
      "pain_point": 8 if any(w in t for w in ["organizer","storage","space","clean","clutter","holder","rack","saving","utility"]) else 6,
      "daily_use": 8 if any(w in t for w in ["kitchen","storage","organizer","clean","holder","drawer","pantry","sink"]) else 6,
      "golden_customer": 8 if category in ("kitchen_utility","home_decor") else 5,
      "lightweight": 9 if not any(w in t for w in ["heavy","large furniture","sofa","cabinet"]) else 2,
      "safe_shipping": 9 if not any(w in t for w in ["glass","ceramic","mirror","crystal"]) else 2,
      "evergreen": 9 if not any(w in t for w in ["christmas","halloween","valentine","easter","seasonal"]) else 2,
      "quality": min(10,max(4,4+rating*1.5)),
      "proven_seller": 10 if reviews>=1000 else 9 if reviews>=500 else 8 if reviews>=50 else 0,
      "content_potential": 9 if any(w in t for w in ["organizer","storage","decor","rack","holder","space","clean","before","after"]) else 7,
    }
    total=round(sum(parts[k]*WEIGHTS[k]/10 for k in WEIGHTS),1)
    return total,parts

def verdict(s):
    return "EXCEPTIONAL" if s>=90 else "STRONG WINNER" if s>=80 else "TEST" if s>=70 else "WATCH" if s>=60 else "REJECT"

async def run_actor(actor,token,payload):
    url=f"https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items"
    async with httpx.AsyncClient(timeout=360) as c:
        r=await c.post(url,params={"token":token,"format":"json","clean":"true"},json=payload)
        if r.status_code>=400: raise RuntimeError(f"Apify actor {actor} HTTP {r.status_code}: {r.text[:1000]}")
        data=r.json()
        if not isinstance(data,list): raise RuntimeError(f"Apify actor {actor} returned unexpected data")
        return data


async def run_rapidapi_amazon(query, req):
    if not RAPIDAPI_KEY:
        return [], "RAPIDAPI_KEY is not configured"
    headers={"x-rapidapi-key":RAPIDAPI_KEY,"x-rapidapi-host":RAPIDAPI_AMAZON_HOST}
    out=[]
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            for q in queries_for_rapid(query):
                r=await client.get(RAPIDAPI_AMAZON_URL,params={"query":q},headers=headers)
                if r.status_code>=400:
                    return out, f"RapidAPI Amazon HTTP {r.status_code}: {r.text[:500]}"
                data=r.json()
                body=data.get("body",data) if isinstance(data,dict) else data
                items=body.get("products",[]) if isinstance(body,dict) else (body if isinstance(body,list) else [])
                out.extend(items[:max(5,min(req.max_products,50))])
        return out,None
    except Exception as e:
        return out,f"RapidAPI Amazon error: {e}"

async def run_rapidapi_aliexpress(queries, req):
    if not RAPIDAPI_KEY:
        return [], "RAPIDAPI_KEY is not configured"
    headers={"x-rapidapi-key":RAPIDAPI_KEY,"x-rapidapi-host":RAPIDAPI_ALIEXPRESS_HOST}
    out=[]
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            for q in queries[:2]:
                r=await client.get(RAPIDAPI_ALIEXPRESS_URL,params={"SearchText":q},headers=headers)
                if r.status_code>=400:
                    return out, f"RapidAPI AliExpress HTTP {r.status_code}: {r.text[:500]}"
                data=r.json(); body=data.get("body",data) if isinstance(data,dict) else data
                items=body.get("products",[]) if isinstance(body,dict) else (body if isinstance(body,list) else [])
                for item in items[:max(20,min(req.max_products*5,100))]:
                    price=item.get("price",{}) if isinstance(item,dict) else {}
                    review=item.get("customerReview",{}) if isinstance(item,dict) else {}
                    flat=dict(item) if isinstance(item,dict) else {}
                    flat["price"]=price.get("current",0) if isinstance(price,dict) else price
                    flat["rating"]=review.get("average",0) if isinstance(review,dict) else 0
                    flat["reviews"]=review.get("reviewsCount",0) if isinstance(review,dict) else 0
                    flat["orders"]=item.get("soldCount",0) if isinstance(item,dict) else 0
                    out.append(flat)
        return out,None
    except Exception as e:
        return out,f"RapidAPI AliExpress error: {e}"

def queries_for_rapid(q):
    return [q]

def source_input(source,queries,req):
    n=max(5,min(req.max_products,50))
    if source=="amazon":
        return {"searchQueries":queries,"marketplace":req.marketplace,
                "maxProductsPerSearch":n,"maxSearchPages":max(1,min(req.amazon_pages,3)),
                "proxyConfiguration":{"useApifyProxy":True,"apifyProxyGroups":["RESIDENTIAL"]}}
    if source=="walmart":
        return {"searchQueries":queries,"maxProductsPerSearch":n,
                "maxSearchPages":max(1,min(req.amazon_pages,3)),
                "sort":"best_match","maxRequestRetries":3}
    if source=="etsy":
        return {"searchQueries":queries,"maxItems":n,"includeDetails":False,
                "country":req.marketplace if req.marketplace in ["US","DE","GB","FR","AU","CA","IT","ES","NL","JP"] else "US"}
    if source=="temu":
        return {"searchQueries":queries,"region":"us","maxProductsPerKeyword":n,"trendingNow":False}
    if source=="home_depot":
        return {"searchQuery":" ".join(queries[:2]),"priceMin":0,
                "priceMax":max(40,req.max_price),"sortBy":"relevance","maxItems":n,
                "includeSponsored":False}
    if source=="target":
        return {"searchQueries":queries,"maxProductsPerSearch":n,
                "maxSearchPages":max(1,min(req.amazon_pages,3)),
                "sort":"relevance","maxRequestRetries":3}
    if source=="aliexpress":
        return {"mode":"search","searchQuery":" ".join(queries[:2]),
                "region":"com","currency":"USD","language":"en_US","sortBy":"orders_desc",
                "priceMin":0,"priceMax":max(1,int(req.max_cogs)),
                "ratingMin":req.min_rating,"shipTo":req.supplier_ship_to,
                "maxItems":max(20,min(req.max_products*5,100)),
                "maxPages":max(1,min(req.supplier_pages,5)),
                "enrichReviews":False,"useProxy":False,"autoEscalateOnBlock":True}
    return {}

async def run_source_safe(source,token,payload):
    try:
        return source,await run_actor(SOURCE_ACTORS[source],token,payload),None
    except Exception as e:
        return source,[],str(e)

def normalize_demand(items,source):
    out=[]
    for x in items:
        n=name_of(x); p=price_of(x)
        if n and p>0:
            out.append({"source":source,"raw":x,"name":n,"price":p,
                        "rating":rating_of(x),"reviews":reviews_of(x),
                        "desc":desc_of(x),"url":first(x,["url","productUrl","product_url","detailPageURL","link"],None),
                        "image":first(x,["image","imageUrl","image_url","thumbnail","thumbnailUrl","primaryImage"],None)})
    return out

async def execute_hunt(category, req):
    if category not in CATEGORIES:
        raise ValueError("Only kitchen_utility and home_decor are allowed")
    token=os.getenv("APIFY_API_TOKEN")
    if not token and not RAPIDAPI_KEY:
        raise RuntimeError("Configure APIFY_API_TOKEN or RAPIDAPI_KEY")

    queries=[req.keyword] if req.keyword else CATEGORIES[category][:5]
    queries=[q for q in queries if q]

    started=now(); c=db()
    cur=c.execute("INSERT INTO hunts(category,status,started_at) VALUES(?,?,?)",(category,"running",started))
    run_id=cur.lastrowid; c.commit(); c.close()

    try:
        # Each discovery marketplace is independent. Amazon can fail without killing the hunt.
        demand_results=await asyncio.gather(*[
            run_source_safe(s,token,source_input(s,queries,req)) for s in DEMAND_SOURCES
        ]) if token else []
        rapid_items, rapid_error = await run_rapidapi_amazon(queries[0], req)
        demand=[]; source_counts={}; errors=[]
        if rapid_error:
            errors.append(rapid_error)
        if rapid_items:
            demand.extend(normalize_demand(rapid_items,"rapidapi_amazon"))
            source_counts["rapidapi_amazon"]=len(rapid_items)
        for source,items,error in demand_results:
            source_counts[source]=len(items)
            if error: errors.append(error)
            demand.extend(normalize_demand(items,source))

        # Supplier data remains AliExpress.
        supplier_results=await asyncio.gather(*[
            run_source_safe(s,token,source_input(s,queries,req)) for s in SUPPLIER_SOURCES
        ]) if token else []
        rapid_supplier_items, rapid_supplier_error = await run_rapidapi_aliexpress(queries, req)
        suppliers=[]; supplier_counts={}
        if rapid_supplier_error:
            errors.append(rapid_supplier_error)
        if rapid_supplier_items:
            supplier_counts["rapidapi_aliexpress"]=len(rapid_supplier_items)
            for x in rapid_supplier_items:
                n=name_of(x); cost=price_of(x)
                if n and cost>0: suppliers.append((n,cost,x,"rapidapi_aliexpress"))
        for source,items,error in supplier_results:
            supplier_counts[source]=len(items)
            if error: errors.append(error)
            for x in items:
                n=name_of(x); cost=price_of(x)
                if n and cost>0:
                    suppliers.append((n,cost,x,source))

        accepted=[]; rejected=0; seen=set()
        for i,x in enumerate(demand):
            n=x["name"]; sell=x["price"]; rating=x["rating"]; reviews=x["reviews"]; desc=x["desc"]
            if not n or sell<=0 or hard_reject(n,desc): rejected+=1; continue
            cat=classify(n+" "+desc+" "+category)
            if cat!=category: rejected+=1; continue
            if sell<req.min_price or sell>req.max_price or rating<req.min_rating or reviews<req.min_reviews:
                rejected+=1; continue

            # Cross-marketplace duplicate suppression.
            key=norm(n)
            if key in seen: continue
            seen.add(key)

            best=None; bestsim=0
            for sn,sc,sx,ssource in suppliers:
                z=sim(n,sn)
                if z>bestsim: bestsim=z; best=(sn,sc,sx,ssource)
            if not best or bestsim<0.38: rejected+=1; continue

            supplier_name,cogs,sx,supplier_source=best
            if cogs<=0 or cogs>req.max_cogs or sell/cogs<req.min_markup:
                rejected+=1; continue

            score,breakdown=score_product(sell,cogs,rating,reviews,n,desc,category)
            if score<req.min_score: rejected+=1; continue

            p={"id":str(first(x["raw"],["asin","id","sku","productId","tcin","usItemId","listingId"],f"{x['source']}-{i}")),
               "name":n,"category_key":category,
               "category":"Kitchen Utility" if category=="kitchen_utility" else "Home Décor",
               "demand_source":x["source"],"selling_price":round(sell,2),
               "cost_of_goods":round(cogs,2),"markup":round(sell/cogs,2),
               "rating":rating,"reviews":reviews,"score":score,"winner_score":score,
               "verdict":verdict(score),"supplier_name":supplier_name,
               "supplier_source":supplier_source,"supplier_match_score":round(bestsim,3),
               "image":x["image"],"url":x["url"],
               "supplier_url":first(sx,["url","productUrl","product_url","detailUrl","link"],None),
               "breakdown":breakdown,"discovered_at":now()}
            save_product(p); accepted.append(p)

        status="success" if demand or suppliers else "error"
        err_text=" | ".join(errors)[:4000] if errors else None
        c=db()
        c.execute("""UPDATE hunts SET status=?,finished_at=?,demand_items=?,supplier_items=?,accepted=?,error=? WHERE id=?""",
                  (status,now(),len(demand),len(suppliers),len(accepted),err_text,run_id))
        c.commit(); c.close()
        return {"status":status,"category":category,"run_id":run_id,
                "demand_items":len(demand),"supplier_items":len(suppliers),
                "accepted":len(accepted),"rejected":rejected,
                "source_counts":source_counts,"supplier_source_counts":supplier_counts,
                "source_errors":errors,
                "products":sorted(accepted,key=lambda p:p["score"],reverse=True)}
    except Exception as e:
        c=db(); c.execute("UPDATE hunts SET status=?,finished_at=?,error=? WHERE id=?",
                          ("error",now(),str(e)[:4000],run_id)); c.commit(); c.close()
        raise

@app.on_event("startup")
def startup(): db().close()

@app.get("/health")
def health():
    db().close()
    return {"status":"ok","version":VERSION,"database":"connected",
            "apify_configured":bool(os.getenv("APIFY_API_TOKEN")),
            "categories_available":list(CATEGORIES.keys()),
            "demand_sources":DEMAND_SOURCES,"supplier_sources":SUPPLIER_SOURCES,
            "rapidapi_amazon_configured":bool(RAPIDAPI_KEY),
            "rapidapi_aliexpress_configured":bool(RAPIDAPI_KEY),
            "rapidapi_amazon_configured":bool(RAPIDAPI_KEY),
            "rapidapi_aliexpress_configured":bool(RAPIDAPI_KEY),
            "rapidapi_aliexpress_configured":bool(RAPIDAPI_KEY)}

@app.get("/sources/status")
def sources():
    return {"status":"ok","apify_configured":bool(os.getenv("APIFY_API_TOKEN")),
            "demand_sources":DEMAND_SOURCES,"supplier_sources":SUPPLIER_SOURCES,
            "sources":{k:{"configured":bool(v),"actor":v} for k,v in SOURCE_ACTORS.items()},
            "rapidapi":{"amazon_configured":bool(RAPIDAPI_KEY),"amazon_host":RAPIDAPI_AMAZON_HOST,
                        "aliexpress_configured":bool(RAPIDAPI_KEY),"aliexpress_host":RAPIDAPI_ALIEXPRESS_HOST}}

@app.get("/products/accepted")
def accepted(limit:int=50,category:Optional[str]=None): return {"status":"success","count":len(products(limit,category)),"products":products(limit,category)}

@app.get("/products/winners")
def winners(limit:int=50): return {"status":"success","products":[p for p in products(limit) if p.get("score",0)>=80]}

@app.get("/products/category/{category}")
def by_category(category:str,limit:int=50):
    if category not in CATEGORIES: return {"status":"error","message":"Only kitchen_utility and home_decor are available"}
    return accepted(limit,category)

@app.get("/stats")
def stats():
    ps=products(200); return {"products":len(ps),"exceptional":sum(p.get("score",0)>=90 for p in ps),"strong_winner":sum(80<=p.get("score",0)<90 for p in ps),"test":sum(70<=p.get("score",0)<80 for p in ps),"watch":sum(60<=p.get("score",0)<70 for p in ps),"kitchen_utility":sum(p.get("category_key")=="kitchen_utility" for p in ps),"home_decor":sum(p.get("category_key")=="home_decor" for p in ps)}

@app.get("/hunt-history")
def history(limit:int=20):
    c=db(); rows=[dict(r) for r in c.execute("SELECT * FROM hunts ORDER BY id DESC LIMIT ?",(max(1,min(limit,100)),)).fetchall()]; c.close(); return {"runs":rows}

@app.get("/verdicts")
def verdicts():
    ps=products(200); return {v:sum(p.get("verdict")==v for p in ps) for v in ["EXCEPTIONAL","STRONG WINNER","TEST","WATCH"]}

@app.post("/auto-hunt/{category}")
async def auto_hunt(category:str, background_tasks:BackgroundTasks, dry_run:bool=False):
    if category not in CATEGORIES and category!="all": return {"status":"error","message":"Category must be kitchen_utility, home_decor or all"}
    # Keep HTTP responsive: execute in background.
    cats=list(CATEGORIES) if category=="all" else [category]
    for cat in cats:
        background_tasks.add_task(_bg_hunt,cat)
    return {"status":"success","message":"Multi-source hunt started","categories":cats,
            "demand_sources":DEMAND_SOURCES,"supplier_sources":SUPPLIER_SOURCES}

async def _bg_hunt(cat):
    try: await execute_hunt(cat,HuntRequest(category=cat,min_score=60,min_price=40,max_price=150,max_cogs=35,min_markup=3,min_rating=4,min_reviews=50))
    except Exception as e: print(f"Hunt {cat} failed: {e}")

@app.post("/admin/hunt-now/{category}")
async def hunt_now(category:str):
    if category not in CATEGORIES: return {"status":"error","message":"Invalid category"}
    try: return await execute_hunt(category,HuntRequest(category=category,min_score=60,min_price=40,max_price=150,max_cogs=35,min_markup=3,min_rating=4,min_reviews=50))
    except Exception as e: return {"status":"error","message":str(e)}

@app.post("/hunt")
async def legacy_hunt(req:HuntRequest):
    cat=req.category if req.category in CATEGORIES else classify(req.keyword or "")
    if cat not in CATEGORIES: cat="kitchen_utility"
    try: return await execute_hunt(cat,req)
    except Exception as e: return {"status":"error","message":str(e)}

@app.get("/")
def root(): return {"service":"Product Hunter API","version":VERSION,"categories":list(CATEGORIES),
            "demand_sources":DEMAND_SOURCES,"supplier_sources":SUPPLIER_SOURCES,
            "endpoints":["/health","/sources/status","/auto-hunt/kitchen_utility",
                         "/auto-hunt/home_decor","/auto-hunt/all","/products/accepted",
                         "/products/winners","/stats"]}
