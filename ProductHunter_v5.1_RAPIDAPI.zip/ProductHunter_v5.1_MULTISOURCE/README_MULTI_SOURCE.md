# Product Hunter v5.1 Multi-Source

Demand discovery sources:
- Amazon
- Walmart
- Etsy
- Temu
- Home Depot
- Target

Supplier source:
- AliExpress

The hunt is fail-soft: if one marketplace fails, the other sources continue.

Filters remain:
- Selling price >= $40
- Preferred $50-$80
- COGS <= $35
- Markup >= 3x
- Rating >= 4.0
- Reviews >= 50
- Score >= 60 accepted
- Kitchen Utility + Home Décor only
- Reject electronics, fragile/glass, ingestible, seasonal, heavy products

Optional Render environment variables:
APIFY_WALMART_ACTOR_ID
APIFY_ETSY_ACTOR_ID
APIFY_TEMU_ACTOR_ID
APIFY_HOMEDEPOT_ACTOR_ID
APIFY_TARGET_ACTOR_ID

Defaults are already included, so these variables are optional.

IMPORTANT: This does not bypass an Apify account-wide monthly hard limit. If Apify reports
"Monthly usage hard limit exceeded", the Apify account limit must be resolved first.
