# RapidAPI fallback

Product Hunter now has RapidAPI fallbacks for both sides of the hunt:

- Demand: Amazon Search API
- Supplier: AliExpress API

This means the hunt can operate even when the Apify account has reached its monthly hard limit,
provided RAPIDAPI_KEY is configured and the selected RapidAPI plans have remaining quota.

Render environment variables:
- RAPIDAPI_KEY = your RapidAPI application key
- RAPIDAPI_AMAZON_HOST = amazon-search-api1.p.rapidapi.com (default)
- RAPIDAPI_AMAZON_URL = https://amazon-search-api1.p.rapidapi.com/amazon-serp.php (default)
- RAPIDAPI_ALIEXPRESS_HOST = aliexpress-api2.p.rapidapi.com (default)
- RAPIDAPI_ALIEXPRESS_URL = https://aliexpress-api2.p.rapidapi.com/search (default)

Do not paste the key into chat.

RapidAPI provider pages/documentation currently show the Amazon Search API returning product search
results and the AliExpress API returning product title, price, sold count and seller information.
The AliExpress API is listed with Basic $0, Pro $10, Ultra $49 and Mega $299 plans; actual quotas
and availability should be confirmed on RapidAPI before use.
