# Product Hunter v6.1 — Ready to Deploy

## What changed
- Price is **not filtered or hard-rejected** during discovery.
- Added country/market selection with market-aware Amazon storefront + Crawlbase geo routing.
- Product cards are clickable and open Product Intelligence.
- Product Intelligence shows image, price, COGS, markup, rating, reviews, source links, score breakdown and sales evidence.
- Added snapshot-based 24h/7d sales tracking. The app shows a number only when repeated cumulative source snapshots support it; otherwise it says `Collecting data`.
- Kept the existing pipeline and scraper transparency views.

## Deploy
- Replace your Render `app/main.py` with `app/main.py` from this package.
- Replace your Vercel/root `index.html` with `index.html` from this package.
- Keep the existing `CRAWLBASE_TOKEN` environment variable. No new secret is required.

## Important
The first run cannot truthfully show 24h/7d sales velocity when historical snapshots do not exist yet. Run repeated hunts so the database accumulates source snapshots; the UI then calculates observed deltas.
