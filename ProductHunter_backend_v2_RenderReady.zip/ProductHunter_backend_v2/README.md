# Wining Product Hunter — Backend v2

FastAPI backend for the Product Hunter iOS app.

## Endpoints
- `GET /health`
- `GET /products/top?limit=50`
- `POST /products/ingest`
- `POST /sources/apify/run`
- `GET /sources/rapidapi/status`

## Render deployment
This folder is ready for Render native Python deployment.

Build command:
```bash
pip install -r requirements.txt
```

Start command:
```bash
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Health check:
```text
/health
```

`render.yaml` contains the same configuration.

## Environment variables
Set these in Render → Environment:

- `APIFY_API_TOKEN`
- `APIFY_ACTOR_ID`
- `APIFY_ACTOR_INPUT_JSON` — JSON input expected by your permitted Apify actor
- `RAPIDAPI_KEY`
- `RAPIDAPI_HOST`
- `RAPIDAPI_URL` (optional)

Never put provider secrets in the iOS app.

## Important data note
The Apify mapper intentionally requires both a selling price and a supplier/COGS field. If a source only gives retail price, it is not treated as a valid winning-product record because the Product Hunter filter requires a real COGS input.

Use only marketplace/provider APIs or Apify actors you are authorized to use commercially and in accordance with their terms.
