from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List, Any
import json
import os
import re
import httpx

app = FastAPI(title="Product Hunter API", version="2.0.0")

PRODUCTS: list["Product"] = []

class Product(BaseModel):
    id: str
    name: str
    category: str = "Unknown"
    source: str = "Unknown"
    selling_price: float
    cost_of_goods: float
    rating: float = 0
    reviews: int = 0
    rank_change_24h: int = 0
    rank_change_7d: int = 0
    wow_factor: float = 5
    perceived_value: float = 5
    pain_point: float = 5
    daily_use: float = 5
    golden_customer: float = 5
    lightweight: float = 5
    safe_shipping: float = 5
    evergreen: float = 5
    quality: float = 5
    proven_seller: float = 5
    content_potential: float = 5

    @property
    def markup(self):
        return self.selling_price / self.cost_of_goods if self.cost_of_goods else 0

    def score(self):
        price = 10 if 50 <= self.selling_price <= 80 else 8 if self.selling_price >= 40 else 2
        cogs = min(10, self.cost_of_goods) if self.cost_of_goods >= 10 else self.cost_of_goods
        markup = 10 if self.markup >= 4 else 9 if self.markup >= 3 else 6 if self.markup >= 2.5 else 4 if self.markup >= 2 else 2
        values = [
            (self.wow_factor,10),(price,8),(cogs,6),(markup,8),
            (self.perceived_value,8),(self.pain_point,8),(self.daily_use,7),
            (self.golden_customer,6),(self.lightweight,5),(self.safe_shipping,5),
            (self.evergreen,5),(self.quality,8),(self.proven_seller,8),
            (self.content_potential,8)
        ]
        return round(sum(v*w/10 for v,w in values), 1)

def public_product(p: Product):
    score = p.score()
    verdict = "WINNER" if score >= 85 else "STRONG TEST" if score >= 75 else "WATCH" if score >= 65 else "DROP"
    return {
        "id": p.id, "name": p.name, "category": p.category, "source": p.source,
        "sellingPrice": p.selling_price, "costOfGoods": p.cost_of_goods,
        "rating": p.rating, "reviews": p.reviews,
        "rankChange24h": p.rank_change_24h, "rankChange7d": p.rank_change_7d,
        "wowFactor": p.wow_factor, "perceivedValue": p.perceived_value,
        "painPoint": p.pain_point, "dailyUse": p.daily_use,
        "goldenCustomer": p.golden_customer, "lightweight": p.lightweight,
        "safeShipping": p.safe_shipping, "evergreen": p.evergreen,
        "quality": p.quality, "provenSeller": p.proven_seller,
        "contentPotential": p.content_potential,
        "markup": round(p.markup, 2), "winnerScore": score, "verdict": verdict
    }

def first_value(item: dict, names: list[str], default=None):
    lowered = {str(k).lower(): v for k, v in item.items()}
    for name in names:
        if name.lower() in lowered and lowered[name.lower()] not in (None, ""):
            return lowered[name.lower()]
    return default

def as_float(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    if value is None:
        return default
    match = re.search(r"[-+]?\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else default

def as_int(value, default=0):
    try:
        return int(as_float(value, default))
    except Exception:
        return default

def env_json(name: str, default: dict):
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else default
    except json.JSONDecodeError:
        return default

def map_apify_item(item: dict, index: int) -> Optional[Product]:
    name = first_value(item, ["name", "title", "productName", "product_name"])
    price = first_value(item, ["price", "sellingPrice", "selling_price", "currentPrice", "current_price"])
    if not name or price is None:
        return None
    selling = as_float(price)
    # If the source has no supplier cost, use an explicit source field only.
    cogs = as_float(first_value(item, ["costOfGoods", "cost_of_goods", "cogs", "supplierPrice", "supplier_price"]))
    if cogs <= 0:
        return None
    return Product(
        id=str(first_value(item, ["id", "asin", "sku", "productId", "product_id"], f"apify-{index}")),
        name=str(name),
        category=str(first_value(item, ["category", "productCategory", "product_category"], "Unknown")),
        source="Apify",
        selling_price=selling,
        cost_of_goods=cogs,
        rating=as_float(first_value(item, ["rating", "stars"])),
        reviews=as_int(first_value(item, ["reviews", "reviewCount", "review_count"])),
        rank_change_24h=as_int(first_value(item, ["rankChange24h", "rank_change_24h"])),
        rank_change_7d=as_int(first_value(item, ["rankChange7d", "rank_change_7d"])),
        wow_factor=as_float(first_value(item, ["wowFactor", "wow_factor"], 5), 5),
        perceived_value=as_float(first_value(item, ["perceivedValue", "perceived_value"], 5), 5),
        pain_point=as_float(first_value(item, ["painPoint", "pain_point"], 5), 5),
        daily_use=as_float(first_value(item, ["dailyUse", "daily_use"], 5), 5),
        golden_customer=as_float(first_value(item, ["goldenCustomer", "golden_customer"], 5), 5),
        lightweight=as_float(first_value(item, ["lightweight"], 5), 5),
        safe_shipping=as_float(first_value(item, ["safeShipping", "safe_shipping"], 5), 5),
        evergreen=as_float(first_value(item, ["evergreen"], 5), 5),
        quality=as_float(first_value(item, ["quality"], 5), 5),
        proven_seller=as_float(first_value(item, ["provenSeller", "proven_seller"], 5), 5),
        content_potential=as_float(first_value(item, ["contentPotential", "content_potential"], 5), 5),
    )

@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0", "products": len(PRODUCTS)}

@app.get("/products/top")
def top_products(limit: int = 50):
    limit = max(1, min(limit, 100))
    ranked = sorted(PRODUCTS, key=lambda p: p.score(), reverse=True)[:limit]
    return {"products": [public_product(p) for p in ranked]}

@app.post("/products/ingest")
def ingest(products: List[Product]):
    global PRODUCTS
    PRODUCTS = products
    return {"accepted": len(products), "winners": sum(p.score() >= 85 for p in products)}

@app.post("/sources/apify/run")
async def run_apify():
    token = os.getenv("APIFY_API_TOKEN")
    actor = os.getenv("APIFY_ACTOR_ID")
    if not token or not actor:
        return {"status": "not_configured", "message": "Set APIFY_API_TOKEN and APIFY_ACTOR_ID in Render environment variables."}

    actor_input = env_json("APIFY_ACTOR_INPUT_JSON", {})
    run_url = f"https://api.apify.com/v2/acts/{actor}/runs?token={token}"
    async with httpx.AsyncClient(timeout=120) as client:
        start = await client.post(run_url, json=actor_input)
        start.raise_for_status()
        run_data = start.json().get("data", {})
        run_id = run_data.get("id")
        dataset_id = run_data.get("defaultDatasetId")
        if not run_id or not dataset_id:
            return {"status": "started", "data": run_data}

        # Wait briefly for small/medium actors. For long actors, return a pending status.
        for _ in range(12):
            status = await client.get(f"https://api.apify.com/v2/actor-runs/{run_id}?token={token}")
            status.raise_for_status()
            run_status = status.json().get("data", {}).get("status")
            if run_status in {"SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT"}:
                break
            import asyncio
            await asyncio.sleep(5)

        final_status = run_status if 'run_status' in locals() else "UNKNOWN"
        if final_status != "SUCCEEDED":
            return {"status": "pending" if final_status not in {"FAILED", "ABORTED", "TIMED-OUT"} else final_status, "runId": run_id, "datasetId": dataset_id}

        data = await client.get(f"https://api.apify.com/v2/datasets/{dataset_id}/items?token={token}&clean=true&format=json")
        data.raise_for_status()
        raw_items = data.json()

    mapped = []
    for i, item in enumerate(raw_items if isinstance(raw_items, list) else []):
        if isinstance(item, dict):
            product = map_apify_item(item, i)
            if product:
                mapped.append(product)
    if mapped:
        global PRODUCTS
        PRODUCTS = mapped
    return {"status": "success", "runId": run_id, "datasetId": dataset_id, "rawItems": len(raw_items) if isinstance(raw_items, list) else 0, "accepted": len(mapped), "winners": sum(p.score() >= 85 for p in mapped)}

@app.get("/sources/rapidapi/status")
def rapidapi_status():
    return {
        "configured": bool(os.getenv("RAPIDAPI_KEY")),
        "host_configured": bool(os.getenv("RAPIDAPI_HOST")),
        "url_configured": bool(os.getenv("RAPIDAPI_URL"))
    }
