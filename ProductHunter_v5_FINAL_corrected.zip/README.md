# Product Hunter v5

Automated Product Hunter for ONLY Kitchen Utility and Home Décor.

## Fixed rules
- Selling price >= $40; sweet spot $50-$80
- COGS <= $35
- Markup >= 3x
- Rating >= 4.0
- Reviews >= 50
- Score >= 60 accepted
- Reject electronics, fragile/glass, ingestible, seasonal, heavy products

## Deploy
Replace the current Render backend app/main.py and requirements.txt with this package. Keep Apify environment variables private.

## Endpoints
POST /auto-hunt/kitchen_utility
POST /auto-hunt/home_decor
POST /auto-hunt/all
GET /products/accepted
GET /products/winners
GET /stats
GET /hunt-history
GET /health

A GitHub Actions workflow triggers both categories every 6 hours and can also be run manually.
