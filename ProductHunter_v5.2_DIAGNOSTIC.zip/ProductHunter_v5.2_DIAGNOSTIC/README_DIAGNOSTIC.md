# Product Hunter v5.2 Diagnostic

This version fixes the key architecture issue: RapidAPI is actually called from the backend.
It keeps Kitchen Utility + Home Decor only and preserves the user's filters.

Flow:
RapidAPI Amazon -> demand products
RapidAPI AliExpress -> supplier products
Apify -> fallback when configured and RapidAPI returns no demand/supplier data
-> category filter -> price/rating/reviews -> supplier matching -> COGS/markup -> 14-point score -> accepted >= 60

Diagnostic endpoints:
GET /health
GET /sources/status
GET /diagnostic/latest
GET /hunt-history

Render environment variables:
RAPIDAPI_KEY = your RapidAPI key
RAPIDAPI_AMAZON_HOST = your Amazon RapidAPI host

Optional:
RAPIDAPI_AMAZON_URL = exact Amazon endpoint URL if your Amazon API uses a path other than /amazon-serp.php
RAPIDAPI_ALIEXPRESS_HOST = aliexpress-api2.p.rapidapi.com
RAPIDAPI_ALIEXPRESS_URL = https://aliexpress-api2.p.rapidapi.com/search

No credentials are included in this package.
