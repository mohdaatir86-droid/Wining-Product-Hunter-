# Product Hunter v6.2 — Demand Signals

Built from the uploaded v6.1 READY_TO_DEPLOY package.

## New working features
- Marketplace rank snapshots and 24h/7d/30d rank velocity when the source exposes an actual sales/bestseller rank.
- Demand Momentum Score with transparent weights:
  - Rank velocity 35%
  - Google Trends 25%
  - Pinterest Trends 15%
  - Sales signal 15%
  - Competition proxy 10%
- Google Trends via SerpApi.
- Pinterest Trends via Pinterest API v5.
- New `/products/trending` endpoint.
- New `/demand-signals/status` endpoint.
- Product Intelligence now shows demand momentum, rank velocity, Google Trends and Pinterest Trends.
- New Demand Signals portal tab.
- Missing API providers are optional and never fabricate trend values.

## Render environment variables
Existing:
- CRAWLBASE_TOKEN
- APIFY_API_TOKEN
- APIFY_DEMAND_ACTOR_ID
- APIFY_SUPPLIER_ACTOR_ID

New:
- SERPAPI_API_KEY
- PINTEREST_ACCESS_TOKEN

Pinterest Trends requires an approved Pinterest API app/token with Trends access. Google Trends uses the SerpApi Google Trends engine.

## Important
The first run cannot show a 7-day rank velocity unless the marketplace source supplies a sales/bestseller rank and historical snapshots exist. The portal will show `Collecting` rather than inventing a value.

## Deploy
Backend: replace Render `app/main.py` with `app/main.py`.
Frontend: replace the hosted/root `index.html` with this `index.html`.
Keep the existing database/environment configuration.
